﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajIndividualniTrening : Form
    {

        private List<TrenerDTO> treneri;
        private TrenerDTO selektovanTrener;
        private List<TipIndividualniTreningDTO> tipoviIndTreninga;
        private TipIndividualniTreningDTO selektovanTipIndTren;
        private IndividualniTreningDTO selektovanIndTrening;        
        private ClanDTO selektovaniClan;
        List<TipClanarineDTO> listaTipovaClanarinaZaDatiTip;
        TipClanarineDTO selektovaniTipClanarine = new TipClanarineDTO();

        

        public DodajIndividualniTrening(ClanDTO selektovaniClan)
        {
            InitializeComponent();
            this.selektovaniClan = selektovaniClan;
            this.selektovanTipIndTren = null;
            this.selektovaniTipClanarine = null;
            this.selektovanIndTrening = null;
            this.selektovanTrener = null;

            treneri = TrenerDAO.sviTreneri();
            tipoviIndTreninga = TipIndividualniTreningDAO.sviTipoviIndividualniTrening();
            
            foreach (TrenerDTO t in treneri)
            {
                comboBoxTrener.Items.Add(t.Ime + "(" + t.Jmbg + ")");
            }

            foreach (TipIndividualniTreningDTO tip in tipoviIndTreninga)
            {
                comboBoxTipIndividualnogTreninga.Items.Add((tip.IdTipaTreninga + " : " + tip.Naziv));
            }


            

                        
                comboBoxTrener.Text = "";
                comboBoxTipIndividualnogTreninga.Text = "";
                

        }
        

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (comboBoxTipIndividualnogTreninga.Text != "" && comboBoxTrener.Text != "" && comboBoxTipClanarine.Text != "")
            {
                
                    selektovanIndTrening = new IndividualniTreningDTO();     
                    selektovaniTipClanarine = new TipClanarineDTO();                    

                    foreach (TipIndividualniTreningDTO t in tipoviIndTreninga)
                    {
                        if ((t.IdTipaTreninga + " : " + t.Naziv).Equals(comboBoxTipIndividualnogTreninga.Text))
                        {
                            selektovanIndTrening.Tip = TipIndividualniTreningDAO.tipIndividualnogTreningaPoID(t.IdTipaTreninga);
                        }
                    }

                    foreach (TrenerDTO t in treneri)
                    {
                        if ((t.Ime + "(" + t.Jmbg + ")").Equals(comboBoxTrener.Text))
                        {
                            selektovanIndTrening.Trener = TrenerDAO.trenerPoJMBG(t.Jmbg);
                        }
                    }

                    listaTipovaClanarinaZaDatiTip = TipClanarineDAO.sviTipoviClanarinaPoIDTipuTreninga(selektovanTipIndTren.IdTipaTreninga);

                    foreach (TipClanarineDTO tipClanarine in listaTipovaClanarinaZaDatiTip)
                    {

                        if ((tipClanarine.Naziv).Equals(comboBoxTipClanarine.Text))
                        {
                            selektovaniTipClanarine = TipClanarineDAO.tipClanarinePoID(tipClanarine.IdTipaClanarine);
                        }
                    }

                    DateTime danasnjiDatum = DateTime.Now;
                    DateTime datumIsteka = DateTime.Now;
                    selektovanIndTrening.DatumKreiranja = danasnjiDatum;
                    selektovanIndTrening.Clan = selektovaniClan;
               

                    if (danasnjiDatum.Month == 12)
                        datumIsteka = new DateTime(danasnjiDatum.Year + 1, 1, danasnjiDatum.Day);
                    else
                        datumIsteka = new DateTime(danasnjiDatum.Year, danasnjiDatum.Month + 1, danasnjiDatum.Day);

                List<IndividualniTreningDTO> sviIndividualniTreninzi = IndividualniTreningDAO.sviAktivniIndividualniTreninzi();

                bool a = true;
                bool postoji = false;
                foreach (IndividualniTreningDTO i in sviIndividualniTreninzi)
                {
                    if(i.Tip.IdTipaTreninga == selektovanIndTrening.Tip.IdTipaTreninga && i.Clan.Jmbg == selektovanIndTrening.Clan.Jmbg && i.Trener.Jmbg == selektovanIndTrening.Trener.Jmbg)
                    {
                        postoji = true;
                    }
                }
                if(!postoji)
                {
                    a = IndividualniTreningDAO.dodavanjeIndividualnogTreninga(selektovanIndTrening);
                }

                bool b = ClanarinaDAO.dodavanjeClanarine(danasnjiDatum.ToString("yyyy-MM-dd"), datumIsteka.ToString("yyyy-MM-dd"), null, selektovaniClan.Jmbg, selektovaniTipClanarine.IdTipaClanarine, null, "Recepcioner");

                    if ( a && b )
                        MessageBox.Show("Uspješno ste kreirali članarinu za odabrani individualni trening.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                

                

                this.Close();

            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBoxTipIndividualnogTreninga_SelectedIndexChanged(object sender, EventArgs e)
        {
            

             foreach (TipIndividualniTreningDTO t in tipoviIndTreninga)
                    {
                        if ((t.IdTipaTreninga + " : " + t.Naziv).Equals(comboBoxTipIndividualnogTreninga.Text))
                        {
                            selektovanTipIndTren = TipIndividualniTreningDAO.tipIndividualnogTreningaPoID(t.IdTipaTreninga);
                        }
                    }

             textBoxOpisTreninga.Text = selektovanTipIndTren.OpisTreninga;

             listaTipovaClanarinaZaDatiTip = TipClanarineDAO.sviTipoviClanarinaPoIDTipuTreninga(selektovanTipIndTren.IdTipaTreninga);


             foreach (TipClanarineDTO tipClanarine in listaTipovaClanarinaZaDatiTip)
            {
                comboBoxTipClanarine.Items.Add(tipClanarine.Naziv);
            }
        }

       
    }
}
