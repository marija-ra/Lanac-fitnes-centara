﻿namespace LanacFitnesCentara.forms
{
    partial class DodajIndividualniTrening
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajIndividualniTrening));
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSacuvaj = new System.Windows.Forms.Button();
            this.buttonOdustani = new System.Windows.Forms.Button();
            this.comboBoxTrener = new System.Windows.Forms.ComboBox();
            this.comboBoxTipClanarine = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxOpisTreninga = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxTipIndividualnogTreninga = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(36, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Trener:";
            // 
            // buttonSacuvaj
            // 
            this.buttonSacuvaj.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonSacuvaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSacuvaj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSacuvaj.Location = new System.Drawing.Point(109, 354);
            this.buttonSacuvaj.Name = "buttonSacuvaj";
            this.buttonSacuvaj.Size = new System.Drawing.Size(75, 23);
            this.buttonSacuvaj.TabIndex = 100;
            this.buttonSacuvaj.Text = "Sačuvaj";
            this.buttonSacuvaj.UseVisualStyleBackColor = false;
            this.buttonSacuvaj.Click += new System.EventHandler(this.buttonSacuvaj_Click);
            // 
            // buttonOdustani
            // 
            this.buttonOdustani.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonOdustani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOdustani.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonOdustani.Location = new System.Drawing.Point(191, 354);
            this.buttonOdustani.Name = "buttonOdustani";
            this.buttonOdustani.Size = new System.Drawing.Size(75, 23);
            this.buttonOdustani.TabIndex = 101;
            this.buttonOdustani.Text = "Odustani";
            this.buttonOdustani.UseVisualStyleBackColor = false;
            this.buttonOdustani.Click += new System.EventHandler(this.buttonOdustani_Click);
            // 
            // comboBoxTrener
            // 
            this.comboBoxTrener.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxTrener.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTrener.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTrener.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxTrener.FormattingEnabled = true;
            this.comboBoxTrener.Location = new System.Drawing.Point(39, 280);
            this.comboBoxTrener.Name = "comboBoxTrener";
            this.comboBoxTrener.Size = new System.Drawing.Size(227, 21);
            this.comboBoxTrener.TabIndex = 102;
            // 
            // comboBoxTipClanarine
            // 
            this.comboBoxTipClanarine.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxTipClanarine.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipClanarine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTipClanarine.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxTipClanarine.FormattingEnabled = true;
            this.comboBoxTipClanarine.Location = new System.Drawing.Point(37, 216);
            this.comboBoxTipClanarine.Name = "comboBoxTipClanarine";
            this.comboBoxTipClanarine.Size = new System.Drawing.Size(227, 21);
            this.comboBoxTipClanarine.TabIndex = 108;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 107;
            this.label6.Text = "Tip članarine:";
            // 
            // textBoxOpisTreninga
            // 
            this.textBoxOpisTreninga.Location = new System.Drawing.Point(38, 90);
            this.textBoxOpisTreninga.Multiline = true;
            this.textBoxOpisTreninga.Name = "textBoxOpisTreninga";
            this.textBoxOpisTreninga.ReadOnly = true;
            this.textBoxOpisTreninga.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxOpisTreninga.Size = new System.Drawing.Size(228, 89);
            this.textBoxOpisTreninga.TabIndex = 110;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(34, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 109;
            this.label4.Text = "Opis treninga:";
            // 
            // comboBoxTipIndividualnogTreninga
            // 
            this.comboBoxTipIndividualnogTreninga.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxTipIndividualnogTreninga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipIndividualnogTreninga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTipIndividualnogTreninga.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxTipIndividualnogTreninga.FormattingEnabled = true;
            this.comboBoxTipIndividualnogTreninga.Location = new System.Drawing.Point(37, 39);
            this.comboBoxTipIndividualnogTreninga.Name = "comboBoxTipIndividualnogTreninga";
            this.comboBoxTipIndividualnogTreninga.Size = new System.Drawing.Size(227, 21);
            this.comboBoxTipIndividualnogTreninga.TabIndex = 112;
            this.comboBoxTipIndividualnogTreninga.SelectedIndexChanged += new System.EventHandler(this.comboBoxTipIndividualnogTreninga_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(34, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 111;
            this.label1.Text = "Tip individualnog treninga :";
            // 
            // DodajIndividualniTrening
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(304, 412);
            this.Controls.Add(this.comboBoxTipIndividualnogTreninga);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxOpisTreninga);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBoxTipClanarine);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxTrener);
            this.Controls.Add(this.buttonOdustani);
            this.Controls.Add(this.buttonSacuvaj);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DodajIndividualniTrening";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodaj članarinu za individualni trening";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSacuvaj;
        private System.Windows.Forms.Button buttonOdustani;
        private System.Windows.Forms.ComboBox comboBoxTrener;
        private System.Windows.Forms.ComboBox comboBoxTipClanarine;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxOpisTreninga;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxTipIndividualnogTreninga;
        private System.Windows.Forms.Label label1;
    }
}