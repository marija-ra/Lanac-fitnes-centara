﻿namespace LanacFitnesCentara.forms
{
    partial class DodajClana
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajClana));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxIme = new System.Windows.Forms.TextBox();
            this.textBoxPrezime = new System.Windows.Forms.TextBox();
            this.textBoxAdresa = new System.Windows.Forms.TextBox();
            this.comboBoxMjesto = new System.Windows.Forms.ComboBox();
            this.buttonSacuvaj = new System.Windows.Forms.Button();
            this.buttonOdustani = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxClanskiBroj = new System.Windows.Forms.TextBox();
            this.buttonDodajMjesto = new System.Windows.Forms.Button();
            this.textBoxJMBG = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1.Location = new System.Drawing.Point(23, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label2.Location = new System.Drawing.Point(23, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prezime:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label3.Location = new System.Drawing.Point(23, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Adresa:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label4.Location = new System.Drawing.Point(23, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mjesto:";
            // 
            // textBoxIme
            // 
            this.textBoxIme.Location = new System.Drawing.Point(121, 57);
            this.textBoxIme.Name = "textBoxIme";
            this.textBoxIme.Size = new System.Drawing.Size(158, 20);
            this.textBoxIme.TabIndex = 4;
            // 
            // textBoxPrezime
            // 
            this.textBoxPrezime.Location = new System.Drawing.Point(121, 99);
            this.textBoxPrezime.Name = "textBoxPrezime";
            this.textBoxPrezime.Size = new System.Drawing.Size(158, 20);
            this.textBoxPrezime.TabIndex = 5;
            // 
            // textBoxAdresa
            // 
            this.textBoxAdresa.Location = new System.Drawing.Point(121, 141);
            this.textBoxAdresa.Name = "textBoxAdresa";
            this.textBoxAdresa.Size = new System.Drawing.Size(158, 20);
            this.textBoxAdresa.TabIndex = 6;
            // 
            // comboBoxMjesto
            // 
            this.comboBoxMjesto.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxMjesto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMjesto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxMjesto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxMjesto.FormattingEnabled = true;
            this.comboBoxMjesto.Location = new System.Drawing.Point(121, 218);
            this.comboBoxMjesto.Name = "comboBoxMjesto";
            this.comboBoxMjesto.Size = new System.Drawing.Size(158, 21);
            this.comboBoxMjesto.TabIndex = 51;
            // 
            // buttonSacuvaj
            // 
            this.buttonSacuvaj.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonSacuvaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSacuvaj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSacuvaj.Location = new System.Drawing.Point(121, 260);
            this.buttonSacuvaj.Name = "buttonSacuvaj";
            this.buttonSacuvaj.Size = new System.Drawing.Size(75, 23);
            this.buttonSacuvaj.TabIndex = 100;
            this.buttonSacuvaj.Text = "Sačuvaj";
            this.buttonSacuvaj.UseVisualStyleBackColor = false;
            this.buttonSacuvaj.Click += new System.EventHandler(this.buttonSacuvaj_Click);
            // 
            // buttonOdustani
            // 
            this.buttonOdustani.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonOdustani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOdustani.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonOdustani.Location = new System.Drawing.Point(204, 260);
            this.buttonOdustani.Name = "buttonOdustani";
            this.buttonOdustani.Size = new System.Drawing.Size(75, 23);
            this.buttonOdustani.TabIndex = 101;
            this.buttonOdustani.Text = "Odustani";
            this.buttonOdustani.UseVisualStyleBackColor = false;
            this.buttonOdustani.Click += new System.EventHandler(this.buttonOdustani_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label5.Location = new System.Drawing.Point(23, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Clanski Broj:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 102;
            this.label6.Text = "JMBG:";
            // 
            // textBoxClanskiBroj
            // 
            this.textBoxClanskiBroj.Location = new System.Drawing.Point(121, 179);
            this.textBoxClanskiBroj.Name = "textBoxClanskiBroj";
            this.textBoxClanskiBroj.Size = new System.Drawing.Size(159, 20);
            this.textBoxClanskiBroj.TabIndex = 7;
            // 
            // buttonDodajMjesto
            // 
            this.buttonDodajMjesto.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonDodajMjesto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDodajMjesto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDodajMjesto.Location = new System.Drawing.Point(26, 259);
            this.buttonDodajMjesto.Name = "buttonDodajMjesto";
            this.buttonDodajMjesto.Size = new System.Drawing.Size(89, 23);
            this.buttonDodajMjesto.TabIndex = 80;
            this.buttonDodajMjesto.Text = "Dodaj Mjesto";
            this.buttonDodajMjesto.UseVisualStyleBackColor = false;
            this.buttonDodajMjesto.Click += new System.EventHandler(this.buttonDodajMjesto_Click);
            // 
            // textBoxJMBG
            // 
            this.textBoxJMBG.Location = new System.Drawing.Point(121, 23);
            this.textBoxJMBG.Name = "textBoxJMBG";
            this.textBoxJMBG.Size = new System.Drawing.Size(158, 20);
            this.textBoxJMBG.TabIndex = 1;
            // 
            // DodajClana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(305, 314);
            this.Controls.Add(this.textBoxJMBG);
            this.Controls.Add(this.buttonDodajMjesto);
            this.Controls.Add(this.textBoxClanskiBroj);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buttonOdustani);
            this.Controls.Add(this.buttonSacuvaj);
            this.Controls.Add(this.comboBoxMjesto);
            this.Controls.Add(this.textBoxAdresa);
            this.Controls.Add(this.textBoxPrezime);
            this.Controls.Add(this.textBoxIme);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DodajClana";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Novi član";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxIme;
        private System.Windows.Forms.TextBox textBoxPrezime;
        private System.Windows.Forms.TextBox textBoxAdresa;
        private System.Windows.Forms.ComboBox comboBoxMjesto;
        private System.Windows.Forms.Button buttonSacuvaj;
        private System.Windows.Forms.Button buttonOdustani;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxClanskiBroj;
        private System.Windows.Forms.Button buttonDodajMjesto;
        private System.Windows.Forms.TextBox textBoxJMBG;
    }
}