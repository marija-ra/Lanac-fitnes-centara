﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajGrupu : Form
    {
        private List<TrenerDTO> treneri;
        private List<TipGrupniTreningDTO> tipoviGrupnogTreninga;
        private GrupaDTO selektovanaGrupa;
        private List<FitnesCentarDTO> fitnesCentri;
        private bool dodaj;
        
        public DodajGrupu(Boolean dodaj, GrupaDTO grupa)
        {
            InitializeComponent();
            this.dodaj = dodaj;
            this.selektovanaGrupa = grupa;

            treneri = TrenerDAO.sviTreneri();
            tipoviGrupnogTreninga = TipGrupniTreningDAO.sviTipoviGrupniTrening();
            fitnesCentri = FitnesCentarDAO.sviFitnesCentri();

            foreach (TrenerDTO t in treneri)
            {
                comboBoxTrener.Items.Add(t.Ime + "(" + t.Jmbg + ")");
            }

            foreach (TipGrupniTreningDTO tip in tipoviGrupnogTreninga)
            {
                comboBoxTipGrupnogTreninga.Items.Add((tip.IdTipaTreninga + " : " + tip.Naziv));
            }

            foreach (FitnesCentarDTO f in fitnesCentri)
            {
                comboBoxFitnesCentar.Items.Add("Fitnes centar " + f.IdFCentra);
            }


            if (dodaj)
            {
                comboBoxTrener.Text = "";
                comboBoxTipGrupnogTreninga.Text = "";
                comboBoxFitnesCentar.Text = "";

            }
            else
            {
                comboBoxTrener.Text = grupa.Trener.Ime + "(" + grupa.Trener.Jmbg + ")";
                comboBoxTipGrupnogTreninga.Text = grupa.Tip.IdTipaTreninga + " : " + grupa.Tip.Naziv;
                comboBoxFitnesCentar.Text = "Fitnes centar " + selektovanaGrupa.FitnesCentar.IdFCentra;
            }

        }

        private void buttonDodajTipGrupnogTreninga_Click(object sender, EventArgs e)
        {
            DodajTipGrupniTrening tgt = new DodajTipGrupniTrening(true, null);
            tgt.ShowDialog();

            comboBoxTipGrupnogTreninga.Items.Clear();
            tipoviGrupnogTreninga = TipGrupniTreningDAO.sviTipoviGrupniTrening();

            foreach (TipGrupniTreningDTO tip in tipoviGrupnogTreninga)
            {
                comboBoxTipGrupnogTreninga.Items.Add(tip.IdTipaTreninga + " : " + tip.Naziv);
            }
        }

        private void buttonDodajTrenera_Click(object sender, EventArgs e)
        {
            DodajZaposlenika dc = new DodajZaposlenika(true, null, "treneri");
            dc.ShowDialog();

            comboBoxTrener.Items.Clear();
            treneri = TrenerDAO.sviTreneri();
            foreach (TrenerDTO t in treneri)
            {
                comboBoxTrener.Items.Add(t.Ime + "(" + t.Jmbg + ")");
            }
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (comboBoxTipGrupnogTreninga.Text != "" && comboBoxTrener.Text != "" && comboBoxFitnesCentar.Text != "")
            {
                if (dodaj)
                {
                    DateTime danasnjiDatum = DateTime.Now;
                    

                    GrupaDTO grupa = new GrupaDTO();
                    grupa.TrenutniBrojClanova = 0;
                    grupa.DatumKreiranja = danasnjiDatum;

                    foreach (TipGrupniTreningDTO t in tipoviGrupnogTreninga)
                    {
                        if ((t.IdTipaTreninga + " : " + t.Naziv).Equals(comboBoxTipGrupnogTreninga.Text))
                        {
                            grupa.Tip = TipGrupniTreningDAO.tipGrupnogTreningaPoID(t.IdTipaTreninga);
                        }
                    }

                    foreach (TrenerDTO t in treneri)
                    {
                        if ((t.Ime + "(" + t.Jmbg + ")").Equals(comboBoxTrener.Text))
                        {
                            grupa.Trener = TrenerDAO.trenerPoJMBG(t.Jmbg);
                        }
                    }

                    foreach (FitnesCentarDTO f in fitnesCentri)
                    {
                        if (("Fitnes centar " + f.IdFCentra).Equals(comboBoxFitnesCentar.Text))
                        {
                            grupa.FitnesCentar = FitnesCentarDAO.fitnesCentarPoID(f.IdFCentra);
                        }
                    }

                    if(GrupaDAO.dodavanjeGrupe(grupa))
                        MessageBox.Show("Uspješno ste dodali grupu.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    foreach (TrenerDTO t in treneri)
                    {
                        if ((t.Ime + "(" + t.Jmbg + ")").Equals(comboBoxTrener.Text))
                        {
                            selektovanaGrupa.Trener = t;
                        }
                    }

                    
                    foreach (TipGrupniTreningDTO t in tipoviGrupnogTreninga)
                    {
                        if ((t.IdTipaTreninga + " : " + t.Naziv).Equals(comboBoxTipGrupnogTreninga.Text))
                        {
                            selektovanaGrupa.Tip = t;
                        }
                    }

                    foreach (FitnesCentarDTO f in fitnesCentri)
                    {
                        if (("Fitnes centar " + f.IdFCentra).Equals(comboBoxFitnesCentar.Text))
                        {
                            selektovanaGrupa.FitnesCentar = FitnesCentarDAO.fitnesCentarPoID(f.IdFCentra);
                        }
                    }

                    if (GrupaDAO.uredjivanjeGrupe(selektovanaGrupa.Tip.IdTipaTreninga, selektovanaGrupa.IdGrupe, selektovanaGrupa.Trener.Jmbg, selektovanaGrupa.FitnesCentar.IdFCentra))
                        MessageBox.Show("Uspješno ste uredili grupu.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                

                
                this.Close();

            }
            else 
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonDodajFitnesCentar_Click(object sender, EventArgs e)
        {
            DodajFitnesCentar dfc = new DodajFitnesCentar();
            dfc.ShowDialog();

            comboBoxTrener.Items.Clear();

            foreach (FitnesCentarDTO f in fitnesCentri)
            {
                comboBoxFitnesCentar.Items.Add("Fitnes centar " + f.IdFCentra);
            }

        }

        
    }}
