﻿namespace LanacFitnesCentara.forms
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.pregledToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dodajNoviFitnesCentarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.članoviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOČlanovimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.instruktoriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOInstruktorimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOKoordinatorimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kurseviToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOKursevimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idGrupe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnNazivTipa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTrajanjeUMinutama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTrenutniBrojClanova = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnKapacitet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnImeTrenera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnJMBGTrenera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ColumnJMBG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnIme = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPrezime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnAdresa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnClanskiBroj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnGrad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMjesto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ObrisiClana = new System.Windows.Forms.Button();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pregledToolStripMenuItem
            // 
            this.pregledToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dodajNoviFitnesCentarToolStripMenuItem});
            this.pregledToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pregledToolStripMenuItem.Name = "pregledToolStripMenuItem";
            this.pregledToolStripMenuItem.Size = new System.Drawing.Size(95, 29);
            this.pregledToolStripMenuItem.Text = "Fitnes centri";
            this.pregledToolStripMenuItem.ToolTipText = "Pregled kurseva sa instruktorima i članovima";
            // 
            // dodajNoviFitnesCentarToolStripMenuItem
            // 
            this.dodajNoviFitnesCentarToolStripMenuItem.Name = "dodajNoviFitnesCentarToolStripMenuItem";
            this.dodajNoviFitnesCentarToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.dodajNoviFitnesCentarToolStripMenuItem.Text = "Dodaj novi fitnes centar";
            this.dodajNoviFitnesCentarToolStripMenuItem.Click += new System.EventHandler(this.dodajNoviFitnesCentarToolStripMenuItem_Click);
            // 
            // članoviToolStripMenuItem
            // 
            this.članoviToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.informacijeOČlanovimaToolStripMenuItem});
            this.članoviToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.članoviToolStripMenuItem.Name = "članoviToolStripMenuItem";
            this.članoviToolStripMenuItem.Size = new System.Drawing.Size(66, 29);
            this.članoviToolStripMenuItem.Text = "Članovi";
            this.članoviToolStripMenuItem.ToolTipText = "Sve informacije o članovima";
            // 
            // informacijeOČlanovimaToolStripMenuItem
            // 
            this.informacijeOČlanovimaToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.informacijeOČlanovimaToolStripMenuItem.Name = "informacijeOČlanovimaToolStripMenuItem";
            this.informacijeOČlanovimaToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.informacijeOČlanovimaToolStripMenuItem.Text = "Informacije o članovima";
            this.informacijeOČlanovimaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOČlanovimaToolStripMenuItem_Click);
            // 
            // instruktoriToolStripMenuItem
            // 
            this.instruktoriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.informacijeOInstruktorimaToolStripMenuItem,
            this.informacijeOKoordinatorimaToolStripMenuItem});
            this.instruktoriToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.instruktoriToolStripMenuItem.Name = "instruktoriToolStripMenuItem";
            this.instruktoriToolStripMenuItem.Size = new System.Drawing.Size(79, 29);
            this.instruktoriToolStripMenuItem.Text = "Zaposleni";
            this.instruktoriToolStripMenuItem.ToolTipText = "Sve informacije o instruktorima";
            // 
            // informacijeOInstruktorimaToolStripMenuItem
            // 
            this.informacijeOInstruktorimaToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.informacijeOInstruktorimaToolStripMenuItem.Name = "informacijeOInstruktorimaToolStripMenuItem";
            this.informacijeOInstruktorimaToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.informacijeOInstruktorimaToolStripMenuItem.Text = "Informacije o trenerima";
            this.informacijeOInstruktorimaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOInstruktorimaToolStripMenuItem_Click);
            // 
            // informacijeOKoordinatorimaToolStripMenuItem
            // 
            this.informacijeOKoordinatorimaToolStripMenuItem.Name = "informacijeOKoordinatorimaToolStripMenuItem";
            this.informacijeOKoordinatorimaToolStripMenuItem.Size = new System.Drawing.Size(229, 22);
            this.informacijeOKoordinatorimaToolStripMenuItem.Text = "Informacije o koordinatorima";
            this.informacijeOKoordinatorimaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOKoordinatorimaToolStripMenuItem_Click);
            // 
            // kurseviToolStripMenuItem
            // 
            this.kurseviToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem,
            this.informacijeOKursevimaToolStripMenuItem,
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem});
            this.kurseviToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.kurseviToolStripMenuItem.Name = "kurseviToolStripMenuItem";
            this.kurseviToolStripMenuItem.Size = new System.Drawing.Size(68, 29);
            this.kurseviToolStripMenuItem.Text = "Treninzi";
            this.kurseviToolStripMenuItem.ToolTipText = "Sve informacije o kursevima";
            // 
            // informacijeOTipovimaGrupnihTreningaToolStripMenuItem
            // 
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem.Name = "informacijeOTipovimaGrupnihTreningaToolStripMenuItem";
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem.Text = "Informacije o tipovima grupnih treninga";
            this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem_Click);
            // 
            // informacijeOKursevimaToolStripMenuItem
            // 
            this.informacijeOKursevimaToolStripMenuItem.BackColor = System.Drawing.Color.White;
            this.informacijeOKursevimaToolStripMenuItem.Name = "informacijeOKursevimaToolStripMenuItem";
            this.informacijeOKursevimaToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.informacijeOKursevimaToolStripMenuItem.Text = "Informacije o grupnim treninzima";
            this.informacijeOKursevimaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOKursevimaToolStripMenuItem_Click);
            // 
            // informacijeOIndividualnimTreninzimaToolStripMenuItem
            // 
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem.Name = "informacijeOIndividualnimTreninzimaToolStripMenuItem";
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem.Text = "Informacije o individualnim treninzima";
            this.informacijeOIndividualnimTreninzimaToolStripMenuItem.Click += new System.EventHandler(this.informacijeOIndividualnimTreninzimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 29);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(10, 49);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(196, 463);
            this.treeView1.TabIndex = 0;
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.groupBox1.Location = new System.Drawing.Point(241, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(603, 152);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(353, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 16);
            this.label9.TabIndex = 9;
            this.label9.Text = "label9";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(353, 73);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "label8";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(114, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "label7";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(63, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "label6";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(296, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Direktor:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(296, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Mjesto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(9, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Radno vrijeme:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(9, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "E mail:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label1.Location = new System.Drawing.Point(7, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.MintCream;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightSalmon;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idGrupe,
            this.ColumnNazivTipa,
            this.ColumnTrajanjeUMinutama,
            this.ColumnTrenutniBrojClanova,
            this.ColumnKapacitet,
            this.ColumnImeTrenera,
            this.ColumnJMBGTrenera});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Coral;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.Location = new System.Drawing.Point(240, 201);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Coral;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Coral;
            this.dataGridView1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(604, 128);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // idGrupe
            // 
            this.idGrupe.HeaderText = "idGrupe";
            this.idGrupe.Name = "idGrupe";
            this.idGrupe.ReadOnly = true;
            this.idGrupe.Visible = false;
            // 
            // ColumnNazivTipa
            // 
            this.ColumnNazivTipa.HeaderText = "Naziv tipa";
            this.ColumnNazivTipa.Name = "ColumnNazivTipa";
            this.ColumnNazivTipa.ReadOnly = true;
            // 
            // ColumnTrajanjeUMinutama
            // 
            this.ColumnTrajanjeUMinutama.HeaderText = "Trajanje u minutama";
            this.ColumnTrajanjeUMinutama.Name = "ColumnTrajanjeUMinutama";
            this.ColumnTrajanjeUMinutama.ReadOnly = true;
            // 
            // ColumnTrenutniBrojClanova
            // 
            this.ColumnTrenutniBrojClanova.HeaderText = "Trenutni broj clanova";
            this.ColumnTrenutniBrojClanova.Name = "ColumnTrenutniBrojClanova";
            this.ColumnTrenutniBrojClanova.ReadOnly = true;
            // 
            // ColumnKapacitet
            // 
            this.ColumnKapacitet.HeaderText = "Kapacitet";
            this.ColumnKapacitet.Name = "ColumnKapacitet";
            this.ColumnKapacitet.ReadOnly = true;
            // 
            // ColumnImeTrenera
            // 
            this.ColumnImeTrenera.HeaderText = "Ime Trenera";
            this.ColumnImeTrenera.Name = "ColumnImeTrenera";
            this.ColumnImeTrenera.ReadOnly = true;
            // 
            // ColumnJMBGTrenera
            // 
            this.ColumnJMBGTrenera.HeaderText = "JMBG Trenera";
            this.ColumnJMBGTrenera.Name = "ColumnJMBGTrenera";
            this.ColumnJMBGTrenera.ReadOnly = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView2);
            this.groupBox2.Controls.Add(this.ObrisiClana);
            this.groupBox2.Location = new System.Drawing.Point(240, 335);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(604, 177);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "članovi";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.MintCream;
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightSalmon;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnJMBG,
            this.ColumnIme,
            this.ColumnPrezime,
            this.ColumnAdresa,
            this.ColumnClanskiBroj,
            this.ColumnGrad,
            this.ColumnMjesto});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Coral;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.Location = new System.Drawing.Point(0, 19);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightSeaGreen;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Coral;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.LightSeaGreen;
            this.dataGridView2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridView2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Coral;
            this.dataGridView2.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(604, 123);
            this.dataGridView2.TabIndex = 13;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // ColumnJMBG
            // 
            this.ColumnJMBG.HeaderText = "JMBG";
            this.ColumnJMBG.Name = "ColumnJMBG";
            this.ColumnJMBG.ReadOnly = true;
            // 
            // ColumnIme
            // 
            this.ColumnIme.HeaderText = "Ime";
            this.ColumnIme.Name = "ColumnIme";
            this.ColumnIme.ReadOnly = true;
            // 
            // ColumnPrezime
            // 
            this.ColumnPrezime.HeaderText = "Prezime";
            this.ColumnPrezime.Name = "ColumnPrezime";
            this.ColumnPrezime.ReadOnly = true;
            // 
            // ColumnAdresa
            // 
            this.ColumnAdresa.HeaderText = "Adresa";
            this.ColumnAdresa.Name = "ColumnAdresa";
            this.ColumnAdresa.ReadOnly = true;
            // 
            // ColumnClanskiBroj
            // 
            this.ColumnClanskiBroj.HeaderText = "Članski broj";
            this.ColumnClanskiBroj.Name = "ColumnClanskiBroj";
            this.ColumnClanskiBroj.ReadOnly = true;
            // 
            // ColumnGrad
            // 
            this.ColumnGrad.HeaderText = "Grad";
            this.ColumnGrad.Name = "ColumnGrad";
            this.ColumnGrad.ReadOnly = true;
            // 
            // ColumnMjesto
            // 
            this.ColumnMjesto.HeaderText = "Mjesto";
            this.ColumnMjesto.Name = "ColumnMjesto";
            this.ColumnMjesto.ReadOnly = true;
            // 
            // ObrisiClana
            // 
            this.ObrisiClana.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ObrisiClana.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ObrisiClana.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ObrisiClana.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ObrisiClana.Location = new System.Drawing.Point(462, 148);
            this.ObrisiClana.Name = "ObrisiClana";
            this.ObrisiClana.Size = new System.Drawing.Size(136, 23);
            this.ObrisiClana.TabIndex = 12;
            this.ObrisiClana.Text = "Obriši člana iz grupe";
            this.ObrisiClana.UseVisualStyleBackColor = false;
            this.ObrisiClana.Click += new System.EventHandler(this.ObrisiClana_Click);
            // 
            // menuStrip2
            // 
            this.menuStrip2.AutoSize = false;
            this.menuStrip2.BackColor = System.Drawing.Color.LightSeaGreen;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(31, 31);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem4,
            this.toolStripMenuItem6,
            this.toolStripMenuItem9,
            this.toolStripMenuItem13});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menuStrip2.Size = new System.Drawing.Size(880, 48);
            this.menuStrip2.TabIndex = 15;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3});
            this.toolStripMenuItem2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(95, 42);
            this.toolStripMenuItem2.Text = "Fitnes centri";
            this.toolStripMenuItem2.ToolTipText = "Pregled kurseva sa instruktorima i članovima";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(223, 24);
            this.toolStripMenuItem3.Text = "Dodaj novi fitnes centar";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.dodajNoviFitnesCentarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5});
            this.toolStripMenuItem4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(66, 42);
            this.toolStripMenuItem4.Text = "Članovi";
            this.toolStripMenuItem4.ToolTipText = "Sve informacije o članovima";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.BackColor = System.Drawing.Color.White;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(222, 24);
            this.toolStripMenuItem5.Text = "Informacije o članovima";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.informacijeOČlanovimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.toolStripMenuItem6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(79, 42);
            this.toolStripMenuItem6.Text = "Zaposleni";
            this.toolStripMenuItem6.ToolTipText = "Sve informacije o instruktorima";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.BackColor = System.Drawing.Color.White;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(255, 24);
            this.toolStripMenuItem7.Text = "Informacije o trenerima";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.informacijeOInstruktorimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(255, 24);
            this.toolStripMenuItem8.Text = "Informacije o koordinatorima";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.informacijeOKoordinatorimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12});
            this.toolStripMenuItem9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(68, 42);
            this.toolStripMenuItem9.Text = "Treninzi";
            this.toolStripMenuItem9.ToolTipText = "Sve informacije o kursevima";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(350, 24);
            this.toolStripMenuItem10.Text = "Informacije o tipovima grupnih treninga";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.informacijeOTipovimaGrupnihTreningaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.BackColor = System.Drawing.Color.White;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(350, 24);
            this.toolStripMenuItem11.Text = "Informacije o grupnim treninzima";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.informacijeOKursevimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(350, 24);
            this.toolStripMenuItem12.Text = "Informacije o tipovima individualnih treninga";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.informacijeOIndividualnimTreninzimaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(12, 42);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(880, 535);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.treeView1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pregled";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem članoviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informacijeOČlanovimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem instruktoriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informacijeOInstruktorimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kurseviToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem pregledToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informacijeOKursevimaToolStripMenuItem;
        //////////////////////
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem informacijeOIndividualnimTreninzimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dodajNoviFitnesCentarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informacijeOKoordinatorimaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem informacijeOTipovimaGrupnihTreningaToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idGrupe;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnNazivTipa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTrajanjeUMinutama;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTrenutniBrojClanova;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnKapacitet;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnImeTrenera;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnJMBGTrenera;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnJMBG;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnIme;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPrezime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnAdresa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnClanskiBroj;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnGrad;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMjesto;
        private System.Windows.Forms.Button ObrisiClana;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;

    }
}