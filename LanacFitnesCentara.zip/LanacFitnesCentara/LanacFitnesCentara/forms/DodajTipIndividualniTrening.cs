﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajTipIndividualniTrening : Form
    {
        private bool dodaj;
        private TipIndividualniTreningDTO selektovaniTipTreninga;
        private TipClanarineDTO selektovanTipClanarine;

        public DodajTipIndividualniTrening(bool dodaj, TipIndividualniTreningDTO tip)
        {
            InitializeComponent();
            this.dodaj = dodaj;
            this.selektovaniTipTreninga = tip;
            List<TipClanarineDTO> tipoviClanarina = TipClanarineDAO.sviTipoviClanarina();
            this.selektovanTipClanarine = new TipClanarineDTO();

            if (dodaj)
            {
                this.Text = "Dodavanje tipa individualnog treninga";
                textBoxNaziv.Text = "";
                textBoxTrajanjeUMinutama.Text = "";
                textBoxOpisTreninga.Text = "";

            }
            else
            {

                this.Text = "Uređivanje tipa individualnog treninga";
                textBoxNaziv.Text = selektovaniTipTreninga.Naziv;
                textBoxTrajanjeUMinutama.Text = Convert.ToString(selektovaniTipTreninga.TrajanjeUMinutama);
                textBoxOpisTreninga.Text = selektovaniTipTreninga.OpisTreninga;


            }

        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {

            if (textBoxNaziv.Text != "" && textBoxTrajanjeUMinutama.Text != "" && textBoxOpisTreninga.Text != "")
            {
                TipIndividualniTreningDTO tip = new TipIndividualniTreningDTO();

                if (dodaj)
                {


                    int trajanjeUMinutama;
                    int kapacitet;

                    if (!int.TryParse(textBoxTrajanjeUMinutama.Text, out trajanjeUMinutama))
                    {
                        MessageBox.Show("Trajanje u minutama mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    

                    tip.TrajanjeUMinutama = Convert.ToInt32(textBoxTrajanjeUMinutama.Text);
                    
                    tip.Naziv = textBoxNaziv.Text;
                    tip.OpisTreninga = textBoxOpisTreninga.Text;

                    if (TipIndividualniTreningDAO.dodavanjeTipaIndividualnogTreninga(tip))
                        MessageBox.Show("Uspješno ste dodali tip.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
                else
                /*uredjivanje tipa*/
                {
                    int trajanjeUMinutama;
                    int kapacitet;

                    if (!int.TryParse(textBoxTrajanjeUMinutama.Text, out trajanjeUMinutama))
                    {
                        MessageBox.Show("Trajanje u minutama mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
 

                    tip.TrajanjeUMinutama = Convert.ToInt32(textBoxTrajanjeUMinutama.Text);


                    if (TipIndividualniTreningDAO.uredjivanjeTipaIndividualnogTreninga(Convert.ToInt32(selektovaniTipTreninga.IdTipaTreninga), textBoxNaziv.Text, Convert.ToInt32(textBoxTrajanjeUMinutama.Text),  textBoxOpisTreninga.Text))
                        MessageBox.Show("Uspješno ste uredili tip.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.Close();

            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
