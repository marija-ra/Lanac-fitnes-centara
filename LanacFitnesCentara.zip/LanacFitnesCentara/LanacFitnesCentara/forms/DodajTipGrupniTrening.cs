﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajTipGrupniTrening : Form
    {
        private bool dodaj;
        private TipGrupniTreningDTO selektovaniTipTreninga;
        private TipClanarineDTO selektovanTipClanarine;

        public DodajTipGrupniTrening(bool dodaj, TipGrupniTreningDTO tip)
        {
            InitializeComponent();
            this.dodaj = dodaj;
            this.selektovaniTipTreninga = tip;
            List<TipClanarineDTO> tipoviClanarina = TipClanarineDAO.sviTipoviClanarina();
            this.selektovanTipClanarine = new TipClanarineDTO();

            if (dodaj)
            {
                this.Text = "Dodavanje tipa grupnog treninga";
                textBoxNaziv.Text = "";
                textBoxTrajanjeUMinutama.Text = "";
                textBoxKapacitet.Text = "";
                textBoxOpisTreninga.Text = "";

                
                
                

            }
            else
            {
            
                this.Text = "Uređivanje tipa grupnog treninga";
                textBoxNaziv.Text = selektovaniTipTreninga.Naziv;
                textBoxTrajanjeUMinutama.Text = Convert.ToString(selektovaniTipTreninga.TrajanjeUMinutama);
                textBoxKapacitet.Text = Convert.ToString(selektovaniTipTreninga.Kapacitet);
                textBoxOpisTreninga.Text = selektovaniTipTreninga.OpisTreninga;

                
            }

        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {

            if (textBoxNaziv.Text != "" && textBoxTrajanjeUMinutama.Text != "" && textBoxKapacitet.Text != "" && textBoxOpisTreninga.Text != "")
            {
                TipGrupniTreningDTO tip = new TipGrupniTreningDTO();

                if (dodaj)
                {
                    

                    int trajanjeUMinutama;
                    int kapacitet;

                    if (!int.TryParse(textBoxTrajanjeUMinutama.Text, out trajanjeUMinutama))
                    {
                        MessageBox.Show("Trajanje u minutama mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (!int.TryParse(textBoxKapacitet.Text, out kapacitet))
                    {
                        MessageBox.Show("Kapacitet mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    tip.TrajanjeUMinutama = Convert.ToInt32(textBoxTrajanjeUMinutama.Text);
                    tip.Kapacitet = Convert.ToInt32(textBoxKapacitet.Text);

                    tip.Naziv = textBoxNaziv.Text;
                    tip.OpisTreninga = textBoxOpisTreninga.Text;

                    if (TipGrupniTreningDAO.dodavanjeTipaGrupnogTreninga(tip))
                        MessageBox.Show("Uspješno ste dodali tip.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);


                }
                else
                /*uredjivanje tipa*/
                {
                    int trajanjeUMinutama;
                    int kapacitet;

                    if (!int.TryParse(textBoxTrajanjeUMinutama.Text, out trajanjeUMinutama))
                    {
                        MessageBox.Show("Trajanje u minutama mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    if (!int.TryParse(textBoxKapacitet.Text, out kapacitet))
                    {
                        MessageBox.Show("Kapacitet mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    tip.TrajanjeUMinutama = Convert.ToInt32(textBoxTrajanjeUMinutama.Text);
                    tip.Kapacitet = Convert.ToInt32(textBoxKapacitet.Text);

                    if (TipGrupniTreningDAO.uredjivanjeTipaGrupnogTreninga(Convert.ToInt32(selektovaniTipTreninga.IdTipaTreninga), textBoxNaziv.Text, Convert.ToInt32(textBoxTrajanjeUMinutama.Text), Convert.ToInt32(textBoxKapacitet.Text), textBoxOpisTreninga.Text))
                        MessageBox.Show("Uspješno ste uredili tip.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                this.Close();
            
            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
               


    }
}
