﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajFitnesCentar : Form
    {
        public DodajFitnesCentar()
        {
            InitializeComponent();
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
            List<ZaposlenikDTO> zaposleni = ZaposlenikDAO.sviZaposleni();

            textBoxEmail.Text = "";
            textBoxRadnoVrijeme.Text = "";
            
            foreach (MjestoDTO m in mjesta)
            {
                comboBoxMjesto.Items.Add(m.Naziv);
            }

            foreach (ZaposlenikDTO z in zaposleni)
            {
                comboBoxZaposleni.Items.Add(z.Ime+ " (" + z.Jmbg+ ")");
            }

        }

        private void buttonDodajMjesto_Click(object sender, EventArgs e)
        {
            DodajMjesto dm = new DodajMjesto(true, null);
            dm.ShowDialog();

            comboBoxMjesto.Items.Clear();
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
            foreach (MjestoDTO m in mjesta)
            {
                comboBoxMjesto.Items.Add(m.Naziv);
            }
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (textBoxEmail.Text != "" && textBoxRadnoVrijeme.Text != "" && comboBoxMjesto.Text != "" && comboBoxZaposleni.Text != "" )
            {
                List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                List<ZaposlenikDTO> zaposleni = ZaposlenikDAO.sviZaposleni();

                FitnesCentarDTO fc = new FitnesCentarDTO();
                fc.Direktor = new ZaposlenikDTO();
                fc.Direktor.Mjesto = new MjestoDTO();
                fc.Mjesto = new MjestoDTO();

                fc.Email = textBoxEmail.Text;
                fc.RadnoVrijeme = textBoxRadnoVrijeme.Text;

                foreach (MjestoDTO m in mjesta)
                {
                    if (m.Naziv.Equals(comboBoxMjesto.Text))
                    {
                        fc.Mjesto.IdMjesta = m.IdMjesta;
                        fc.Mjesto.Grad = m.Grad;
                        fc.Mjesto.Naziv = m.Naziv;

                        
                    }
                }

                foreach (ZaposlenikDTO z in zaposleni)
                {
                    if ((z.Ime + " (" + z.Jmbg + ")").Equals(comboBoxZaposleni.Text))
                    {
                        fc.Direktor.Jmbg = z.Jmbg;
                        fc.Direktor.Ime = z.Ime;
                        fc.Direktor.Prezime = z.Prezime;
                        fc.Direktor.Adresa = z.Adresa;

                        fc.Direktor.Mjesto.IdMjesta = z.Mjesto.IdMjesta;
                        fc.Direktor.Mjesto.Grad = z.Mjesto.Grad;
                        fc.Direktor.Mjesto.Regija = z.Mjesto.Regija;
                        fc.Direktor.Mjesto.Naziv = z.Mjesto.Naziv;


                    }
                }

                if (FitnesCentarDAO.dodavanjeFitnesCentra(fc))
                    MessageBox.Show("Uspješno ste dodali fitnes centar.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
