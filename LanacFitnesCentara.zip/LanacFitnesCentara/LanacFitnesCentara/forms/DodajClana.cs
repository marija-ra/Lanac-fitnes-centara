﻿using LanacFitnesCentara.db.dto;
using LanacFitnesCentara.db.dao;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajClana : Form
    {
        private bool dodaj;
        private ClanDTO selektovaniClan;


        public DodajClana(bool dodaj, ClanDTO clan)
        {
            InitializeComponent();
            this.dodaj = dodaj;
            this.selektovaniClan = clan;
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();   


            if (dodaj)
            {
                this.Text = "Dodavanje člana";
                textBoxJMBG.Text = "";
                textBoxIme.Text = "";
                textBoxPrezime.Text = "";
                textBoxAdresa.Text = "";
                textBoxClanskiBroj.Text = "";

                foreach (MjestoDTO m in mjesta)
                {
                    comboBoxMjesto.Items.Add(m.Naziv);
                }
            }
            else
            {
                
                this.Text = "Uređivanje člana";
                textBoxJMBG.Text = clan.Jmbg;
                textBoxIme.Text = clan.Ime;
                textBoxPrezime.Text = clan.Prezime;
                textBoxAdresa.Text = clan.Adresa;
                textBoxClanskiBroj.Text = Convert.ToString(clan.ClanskiBroj);
                
                int brojac1 = 0;
                int pom1 = 0;

                foreach (MjestoDTO m in mjesta)
                {
                    comboBoxMjesto.Items.Add(m.Naziv);
                    if (m.IdMjesta == clan.Mjesto.IdMjesta)
                    {
                        pom1 = brojac1;
                    }
                    brojac1++;
                }

                comboBoxMjesto.SelectedIndex = pom1;
            }
        }

        private void buttonDodajMjesto_Click(object sender, EventArgs e)
        {
            DodajMjesto dm = new DodajMjesto(true, null);
            dm.ShowDialog();

            comboBoxMjesto.Items.Clear();
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta(); 
            foreach (MjestoDTO m in mjesta)
            {
                comboBoxMjesto.Items.Add(m.Naziv);
            }
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (textBoxJMBG.Text != "" && textBoxIme.Text != "" && textBoxPrezime.Text != "" && textBoxAdresa.Text != "" && textBoxClanskiBroj.Text != "" && comboBoxMjesto.Text != "")
            {
                if (dodaj)
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                    ClanDTO clan = new ClanDTO();
                    clan.Mjesto = new MjestoDTO();


                    int clanskibroj;

                    if (!int.TryParse(textBoxClanskiBroj.Text, out clanskibroj))
                    {
                        MessageBox.Show("clanski broj mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    clan.ClanskiBroj = Convert.ToInt32(textBoxClanskiBroj.Text);

                    
                    
                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            clan.Jmbg = textBoxJMBG.Text;
                            clan.Ime = textBoxIme.Text;
                            clan.Prezime = textBoxPrezime.Text;
                            clan.Adresa = textBoxAdresa.Text;
                            clan.Mjesto.IdMjesta = m.IdMjesta;
                            clan.Mjesto.Grad = m.Grad;
                            clan.Mjesto.Naziv = m.Naziv;

                            if (ClanDAO.dodavanjeClana(clan))
                                MessageBox.Show("Uspješno ste dodali člana.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }    
                    }

                    
                   
                }
                else
                    /*uredjivanje clana*/
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();

                    int clanskibroj;

                    if (!int.TryParse(textBoxClanskiBroj.Text, out clanskibroj))
                    {
                        MessageBox.Show("clanski broj mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            if(ClanDAO.uredjivanjeClana(textBoxJMBG.Text, textBoxIme.Text, textBoxPrezime.Text, textBoxAdresa.Text, m.IdMjesta, Convert.ToInt32(textBoxClanskiBroj.Text), selektovaniClan.Jmbg))
                                MessageBox.Show("Uspješno ste uredili člana.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                  }

                this.Close();
                
            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
