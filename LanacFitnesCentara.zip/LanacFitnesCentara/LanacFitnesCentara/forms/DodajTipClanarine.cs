﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajTipClanarine : Form
    {
        TipTreningaDTO selektovaniTipTreninga = new TipTreningaDTO();

        public DodajTipClanarine(int idTipaTreninga)
        {
            InitializeComponent();
            selektovaniTipTreninga.IdTipaTreninga = idTipaTreninga;
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (textBoxNaziv.Text != "" && textBoxCijena.Text != "" )
            {
                int cijena;

                if (!int.TryParse(textBoxCijena.Text, out cijena))
                {
                    MessageBox.Show("cijena mora biti broj.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


                TipClanarineDTO tc = new TipClanarineDTO();
                tc.TipTreninga = new TipTreningaDTO();

                tc.Naziv = textBoxNaziv.Text;
                tc.Cijena = Convert.ToInt32(textBoxCijena.Text);
                tc.TipTreninga.IdTipaTreninga = selektovaniTipTreninga.IdTipaTreninga;

                if (TipClanarineDAO.dodavanjeTipaClanarine(tc))
                    MessageBox.Show("Uspješno ste dodali tip članarine.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
