﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajClanarinu : Form
    {
        private ClanDTO selektovaniClan;
        List<TipClanarineDTO> listaTipovaClanarina;
        TipTreningaDTO selektovanTipTreninga = new TipTreningaDTO();
        GrupaDTO selektovanaGrupa = new GrupaDTO();
        TipClanarineDTO selektovaniTipClanarine = new TipClanarineDTO();


        public DodajClanarinu(ClanDTO clan)
        {
            InitializeComponent();
            this.selektovaniClan = clan;
            this.selektovanTipTreninga = null;
            this.selektovanaGrupa = null;
            this.selektovaniTipClanarine = null;

            listaTipovaClanarina = TipClanarineDAO.sviTipoviClanarina();

            comboBoxTipClanarine.Text = "";
            textBoxOpisTreninga.Text = "";
            comboBoxSlobodneGrupe.Text = "";

            dataGridView2.Rows.Clear();

            foreach (TipClanarineDTO tipClanarine in listaTipovaClanarina)
            {
                
                comboBoxTipClanarine.Items.Add(TipTreningaDAO.tipTreningaPoID(tipClanarine.TipTreninga.IdTipaTreninga).Naziv + " "+ tipClanarine.Naziv);
            }


        }

        private void comboBoxTipClanarine_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxSlobodneGrupe.Items.Clear();
            dataGridView2.Rows.Clear();

            foreach (TipClanarineDTO t in listaTipovaClanarina)
            { 
                if((TipTreningaDAO.tipTreningaPoID(t.TipTreninga.IdTipaTreninga).Naziv + " "+ t.Naziv).Equals(comboBoxTipClanarine.Text))
                {
                    selektovaniTipClanarine = t;
                    selektovanTipTreninga = TipTreningaDAO.tipTreningaPoID(t.TipTreninga.IdTipaTreninga);
                    textBoxOpisTreninga.Text = selektovanTipTreninga.OpisTreninga;
                }
            }

            List<GrupaDTO> slobodneGrupe = GrupaDAO.sveSlobodneGrupeTipa(selektovanTipTreninga.IdTipaTreninga);
            foreach (GrupaDTO g in slobodneGrupe)
            {
                comboBoxSlobodneGrupe.Items.Add(selektovanTipTreninga.Naziv + ", Fitnes centar "+ g.FitnesCentar.IdFCentra+", "  + g.Trener.Ime + " " + g.Trener.Prezime);
               
            
            }

        }

        private void comboBoxSlobodneGrupe_SelectedIndexChanged(object sender, EventArgs e)
        {

            List<GrupaDTO> slobodneGrupe = GrupaDAO.sveSlobodneGrupeTipa(selektovanTipTreninga.IdTipaTreninga);
            foreach (GrupaDTO g in slobodneGrupe)
            {
                if ((selektovanTipTreninga.Naziv + ", Fitnes centar " + g.FitnesCentar.IdFCentra + ", " + g.Trener.Ime + " " + g.Trener.Prezime).Equals(comboBoxSlobodneGrupe.Text))
                {
                    selektovanaGrupa = g;
                    popuniDataGridTermini(g.IdGrupe);
                }
               
            }
        }

        public void popuniDataGridTermini(int idgrupe)
        {
            dataGridView2.Rows.Clear();
            List<TerminDTO> termini = TerminDAO.sviTerminiPoIDGrupe(idgrupe);

            foreach (TerminDTO termin in termini)
            {
                dataGridView2.Rows.Add(termin.DanUSedmici.Naziv, termin.Vrijeme);
            }

            dataGridView2.ClearSelection();
            
            
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (comboBoxTipClanarine.Text != "" &&  comboBoxSlobodneGrupe.Text != "" )
            {


                DateTime danasnjiDatum = DateTime.Now;
                DateTime datumIsteka;
                int godina = danasnjiDatum.Year;

                if (danasnjiDatum.Month == 12)
                    datumIsteka = new DateTime(danasnjiDatum.Year+1, 1, danasnjiDatum.Day);
                else
                    datumIsteka = new DateTime(danasnjiDatum.Year, danasnjiDatum.Month + 1, danasnjiDatum.Day);

                List<ClanDTO> clanoviUSelektovanojGrupi = ClanDAO.sviClanoviUGrupi(selektovanaGrupa.IdGrupe);
               

                bool containsItem = clanoviUSelektovanojGrupi.Any(clan => clan.jmbg == selektovaniClan.Jmbg);
                if (containsItem) {
                    MessageBox.Show("Clan već postoji u odabranoj grupi.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    if (ClanarinaDAO.dodavanjeClanarine(danasnjiDatum.ToString("yyyy-MM-dd"), datumIsteka.ToString("yyyy-MM-dd"), selektovanaGrupa.IdGrupe, selektovaniClan.Jmbg, selektovaniTipClanarine.IdTipaClanarine, selektovanaGrupa.FitnesCentar.IdFCentra, "Recepcioner")) ;
                    MessageBox.Show("Uspješno ste dodali članarinu.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }


                
            }

            
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
