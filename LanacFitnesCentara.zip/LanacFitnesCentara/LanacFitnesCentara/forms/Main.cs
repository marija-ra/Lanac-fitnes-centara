﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class Main : Form
    {
        private FitnesCentarDTO selektovanFitnesCentra;
        private GrupaDTO selektovanaGrupa;
        private ClanDTO selektovanClan;

        

        public Main()
        {
            InitializeComponent();
            
            
            dataGridView2.Rows.Clear();
            dataGridView1.Rows.Clear();

            reloadTreeView();

            List<FitnesCentarDTO> fitnesCentri = FitnesCentarDAO.sviFitnesCentri();

            if (treeView1.GetNodeAt(0, 0) != null)
            {

                TreeNode selektovaniNode = treeView1.GetNodeAt(0, 0);

                
                foreach (FitnesCentarDTO f in fitnesCentri)
                {
                    if (selektovaniNode.Text.Equals("Fitnes centar : " + f.IdFCentra))
                    {
                        label1.Text = "Fitnes centar : " + f.IdFCentra;
                        label6.Text = f.Email;
                        label7.Text = f.RadnoVrijeme;
                        label8.Text = f.Mjesto.Naziv;

                        ZaposlenikDTO direktor = new ZaposlenikDTO();
                        direktor = ZaposlenikDAO.zaposlenikPoJMBG(f.Direktor.Jmbg);
                        label9.Text = direktor.Ime + " " + direktor.Prezime; 

                        selektovanFitnesCentra = f;

                        popuniDataGrid(selektovanFitnesCentra.IdFCentra);

                    }
                }
            }
            
        }

        public void reloadTreeView()
        {
            treeView1.Nodes.Clear();
            List<FitnesCentarDTO> fitnesCentri = FitnesCentarDAO.sviFitnesCentri();

            foreach (FitnesCentarDTO fc in fitnesCentri)
            {

                TreeNode treeNode = new TreeNode("Fitnes centar : " + fc.IdFCentra);
                treeNode.Name = "fc" + fc.IdFCentra;                
                treeView1.Nodes.Add(treeNode);
            }
        }

        private void informacijeOČlanovimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clanovi c = new Clanovi();
            c.ShowDialog();
        }

        private void informacijeOInstruktorimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string vrsta = "treneri";
            Zaposleni z = new Zaposleni(vrsta);
            z.ShowDialog();

        }

        private void informacijeOKoordinatorimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string vrsta = "koordinatori";
            Zaposleni z = new Zaposleni(vrsta);
            z.ShowDialog();
        }

        private void dodajNoviTipČlanarineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*DodajTipClanarine dtc = new DodajTipClanarine();
            dtc.ShowDialog();*/
        }

        private void informacijeOKursevimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GrupeClanovi g = new GrupeClanovi();
            g.ShowDialog();
        }

        private void informacijeOTipovimaGrupnihTreningaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GrupniTreningTip gtt = new GrupniTreningTip();
            gtt.ShowDialog();
        }

        private void dodajNoviFitnesCentarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DodajFitnesCentar dfc = new DodajFitnesCentar();
            dfc.ShowDialog();
            reloadTreeView();
        }

        public void popuniDataGrid(int idFCentra)
        {
            dataGridView1.Rows.Clear();
            List<GrupaDTO> grupe = GrupaDAO.sveAktivneGrupePoIDFitnesCentar(idFCentra);
            foreach (GrupaDTO grupa in grupe)
            {
                dataGridView1.Rows.Add(grupa.IdGrupe, grupa.Tip.Naziv, grupa.Tip.TrajanjeUMinutama, grupa.TrenutniBrojClanova, grupa.Tip.Kapacitet, grupa.Trener.Ime, grupa.Trener.Jmbg);
            }

            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                int idGrupe = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idGrupe"].Value);
                selektovanaGrupa = GrupaDAO.grupaPoID(idGrupe);
                popuniDataGridClanovi(selektovanaGrupa.IdGrupe);
            }
            else
                selektovanaGrupa = null;
        }

        public void popuniDataGridClanovi(int idGrupe)
        {
            dataGridView2.Rows.Clear();
            List<ClanDTO> clanovi = ClanDAO.sviAktivniClanoviUGrupi(selektovanaGrupa.IdGrupe);
            foreach (ClanDTO clan in clanovi)
            {
                dataGridView2.Rows.Add(clan.Jmbg, clan.Ime, clan.Prezime, clan.Adresa, clan.ClanskiBroj, clan.Mjesto.Grad, clan.Mjesto.Naziv);
            }

            if (dataGridView2.RowCount != 0)
            {
                dataGridView2.Rows[0].Selected = true;
                string jmbg = Convert.ToString(dataGridView2.SelectedRows[0].Cells["ColumnJMBG"].Value);
                selektovanClan = ClanDAO.clanPoJMBG(jmbg);

            }
            else
                selektovanClan = null;
        }
        
        
        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            
            List<FitnesCentarDTO> fitnesCentri = FitnesCentarDAO.sviFitnesCentri();
            TreeNode tnClicked = treeView1.GetNodeAt(e.Location);


            foreach (FitnesCentarDTO f in fitnesCentri)
            {
                if (tnClicked.Text.Equals("Fitnes centar : " + f.IdFCentra))
                {
                    label1.Text = "Fitnes centar : " + f.IdFCentra;
                    label6.Text = f.Email;
                    label7.Text = f.RadnoVrijeme;
                    label8.Text = f.Mjesto.Naziv;

                    ZaposlenikDTO direktor = new ZaposlenikDTO();
                    direktor = ZaposlenikDAO.zaposlenikPoJMBG(f.Direktor.Jmbg);
                    label9.Text = direktor.Ime + " " + direktor.Prezime; 
                    selektovanFitnesCentra = f;

                    dataGridView1.Rows.Clear();
                    dataGridView2.Rows.Clear();

                    popuniDataGrid(selektovanFitnesCentra.IdFCentra);
                    

                }
            }
          
        }

        private void ObrisiClana_Click(object sender, EventArgs e)
        {
            if (selektovanaGrupa != null && selektovanClan != null)
            {
                if(GrupaDAO.obrisiClanaIzGrupe(selektovanClan.Jmbg, selektovanaGrupa.IdGrupe))
                    MessageBox.Show("Uspješno ste obrisali člana iz grupe", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid(selektovanFitnesCentra.IdFCentra);
            }
            else
                MessageBox.Show("Selektujte grupu i člana", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int idGrupe = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idGrupe"].Value);
                selektovanaGrupa = GrupaDAO.grupaPoID(idGrupe);
                popuniDataGridClanovi(idGrupe);
            }
            else
            {
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                selektovanClan = ClanDAO.clanPoJMBG(jmbg);

            }
            else
            {
                selektovanClan = null;
                dataGridView2.Rows.Clear();
            }
        }

        private void informacijeOIndividualnimTreninzimaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IndividualniTreningTip itt = new IndividualniTreningTip();
            itt.ShowDialog();
        }

        
        
    }
}
