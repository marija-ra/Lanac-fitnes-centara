﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class Grupe : Form

    {
        int idTipaGrupe;
        
        private GrupaDTO selektovanaGrupa;
        private TerminDTO selektovanTermin;
        private TipGrupniTreningDTO tip;

        public Grupe(int idTipaGrupe)
        {
            InitializeComponent();
            this.idTipaGrupe = idTipaGrupe;
            tip = TipGrupniTreningDAO.tipGrupnogTreningaPoID(idTipaGrupe);
            selektovanaGrupa = null;
            selektovanTermin = null;
            textBoxOpisTipaGrupe.Text = tip.OpisTreninga;
            
            dataGridView2.Rows.Clear();
            popuniDataGrid();
        }

        public void popuniDataGrid()
        {
            dataGridView1.Rows.Clear();
            List<GrupaDTO> grupe = GrupaDAO.sveGrupeTipa(idTipaGrupe);
            List<GrupaDTO> aktivneGrupe = GrupaDAO.sveAktivneGrupe();

            foreach (GrupaDTO grupa in grupe)
            {
                dataGridView1.Rows.Add(grupa.IdGrupe,grupa.Tip.Naziv,grupa.Tip.TrajanjeUMinutama,grupa.TrenutniBrojClanova,grupa.Tip.Kapacitet,grupa.Trener.Ime,grupa.Trener.Jmbg);
            }


            foreach (DataGridViewRow gridRow in dataGridView1.Rows)
            {
                int idGrupe = Convert.ToInt32(gridRow.Cells["idGrupe"].Value);
                

                bool containsItem = aktivneGrupe.Any(grupa => grupa.IdGrupe == idGrupe);
                if (!containsItem)
                {
                    
                    gridRow.DefaultCellStyle.BackColor = Color.Gray;
                }

                
                
            }

            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                int idGrupe = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idGrupe"].Value);
                selektovanaGrupa = GrupaDAO.grupaPoID(idGrupe);
                popuniDataGridTermini(selektovanaGrupa.IdGrupe);
            }
            else
                selektovanaGrupa = null;
        }

        public void popuniDataGridTermini(int idgrupe)
        {
            dataGridView2.Rows.Clear();
            List<TerminDTO> termini = TerminDAO.sviTerminiPoIDGrupe(idgrupe);

            foreach (TerminDTO termin in termini)
            {
                dataGridView2.Rows.Add(termin.IdTermina,termin.DanUSedmici.Naziv,termin.Vrijeme);
            }

            if (dataGridView2.RowCount != 0)
            {
                dataGridView2.Rows[0].Selected = true;
                int IDTermina = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTermina"].Value);
                selektovanTermin = TerminDAO.terminPoID(IDTermina);

            }
            else
                selektovanTermin = null;
        }

        private void buttonDodajNoviTermin_Click(object sender, EventArgs e)
        {
            DodajTermin dt = new DodajTermin("grupni", selektovanaGrupa.IdGrupe, null);
            dt.ShowDialog();
            popuniDataGrid();
            if(selektovanaGrupa != null)
                popuniDataGridTermini(selektovanaGrupa.IdGrupe);

        }

        private void buttonZatvori_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DodajGrupu dg = new DodajGrupu(true, null);
            dg.ShowDialog();
            popuniDataGrid();
            if(selektovanaGrupa != null)
                popuniDataGridTermini(selektovanaGrupa.IdGrupe);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (selektovanaGrupa != null)
            {
                if (GrupaDAO.brisanjeGrupe(selektovanaGrupa.IdGrupe))
                    MessageBox.Show("Uspješno ste obrisali grupu : " + selektovanaGrupa.Tip.Naziv , "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
                if (selektovanaGrupa != null)
                    popuniDataGridTermini(selektovanaGrupa.IdGrupe);
            }
            else
                MessageBox.Show("Selektujte grupu kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (selektovanaGrupa != null)
            {
                DodajGrupu dg = new DodajGrupu(false, selektovanaGrupa);
                dg.ShowDialog();
                popuniDataGrid();
                if (selektovanaGrupa != null)
                    popuniDataGridTermini(selektovanaGrupa.IdGrupe);
            }
            else
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int idGrupe = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idGrupe"].Value);
                selektovanaGrupa = GrupaDAO.grupaPoID(idGrupe);
                popuniDataGridTermini(selektovanaGrupa.IdGrupe);
            }
            else
            {
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonObrisiTermin_Click(object sender, EventArgs e)
        {
            if (selektovanTermin != null)
            {
                if (TerminDAO.brisanjeTermina(selektovanTermin.IdTermina))
                    MessageBox.Show("Uspješno ste obrisali termin", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte termin kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 1)
            {
                int idTermina = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTermina"].Value);
                selektovanTermin = TerminDAO.terminPoID(idTermina);
            }
            else
            {
                MessageBox.Show("Selektujte termin koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
