﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajTermin : Form
    {
        private GrupaDTO selektovanaGrupa = new GrupaDTO();
        private IndividualniTreningDTO selektovanIndividualniTrening = new IndividualniTreningDTO();
        private string vrstaTermina;

        public DodajTermin(string vrstaTermina,int? idGrupe, int? idIndTreninga)
        {
            InitializeComponent();
            if(idGrupe != null)
                selektovanaGrupa = GrupaDAO.grupaPoID(idGrupe.Value);
            if (idIndTreninga != null)
                selektovanIndividualniTrening = IndividualniTreningDAO.individualniTreningPoID(idIndTreninga.Value);
            this.vrstaTermina = vrstaTermina;

            if ("individualni".Equals(vrstaTermina)) {
                label2.Visible = false;
                comboBoxSala.Visible = false;
                button1.Visible = false;
            
            }
            else if ("grupni".Equals(vrstaTermina))
            {
                label2.Visible = true;
                comboBoxSala.Visible = true;
                button1.Visible = true;
                List<SalaDTO> sale = SalaDAO.sveSalePoIDFitnesCentra(selektovanaGrupa.FitnesCentar.IdFCentra, selektovanaGrupa.Tip.Kapacitet);
            
                foreach (SalaDTO s in sale)
                {
                    comboBoxSala.Items.Add("Fitnes centar: " + s.FitnesCentar.IdFCentra + ": sala " + s.IdSale);
                }
            
            }


            List<KoordinatorDTO> koordinatori = KoordinatorDAO.sviKoordinatori();
            List<DaniDTO> daniUSedmici = DaniDAO.sviDani();

            
            foreach (DaniDTO d in daniUSedmici)
            {
                comboBoxDan.Items.Add(d.Naziv);
            }

            foreach (KoordinatorDTO k in koordinatori)
            {
                comboBoxKoordinator.Items.Add(k.Ime + "("+ k.Jmbg+")");
                
            }
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if ("individualni".Equals(vrstaTermina))
            {
                if (comboBoxDan.Text != "" && comboBoxKoordinator.Text != "")
                {
                    List<KoordinatorDTO> koordinatori = KoordinatorDAO.sviKoordinatori();
                    List<DaniDTO> daniUSedmici = DaniDAO.sviDani();

                    TerminDTO termin = new TerminDTO();
                    termin.Koordinator = new KoordinatorDTO();
                    termin.Grupa = new GrupaDTO();
                    termin.DanUSedmici = new DaniDTO();
                    termin.IndividualniTrening = IndividualniTreningDAO.individualniTreningPoID(selektovanIndividualniTrening.IdIndividualnogTreninga);

                    termin.Vrijeme = dateTimePicker2.Value.TimeOfDay.ToString();

                    foreach (DaniDTO d in daniUSedmici)
                    {
                        if (d.Naziv.Equals(comboBoxDan.Text))
                        {
                            termin.DanUSedmici.IdDana = d.IdDana;
                        }

                    }


                    foreach (KoordinatorDTO k in koordinatori)
                    {
                        if ((k.Ime + "(" + k.Jmbg + ")").Equals(comboBoxKoordinator.Text))
                        {
                            termin.Koordinator.Jmbg = k.Jmbg;
                        }
                    }

                    if (TrenerDAO.provjeraZauzetostiTerminaZaTrenera(termin.Vrijeme, null, termin.IndividualniTrening.IdIndividualnogTreninga, termin.DanUSedmici.IdDana))
                    {
                        MessageBox.Show("Trener je zauzet u odabranom terminu!", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        if (TerminDAO.dodavanjeTerminaZaIndividualni(termin))
                        {
                            MessageBox.Show("Uspješno ste dodali termin.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                        else
                            MessageBox.Show("Greška prilikom dodavanja termina.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }

                else
                    MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ("grupni".Equals(vrstaTermina))
            {
                if (comboBoxDan.Text != "" && comboBoxSala.Text != "" && comboBoxKoordinator.Text != "")
                {
                    List<KoordinatorDTO> koordinatori = KoordinatorDAO.sviKoordinatori();
                    List<DaniDTO> daniUSedmici = DaniDAO.sviDani();
                    List<SalaDTO> sale = SalaDAO.sveSalePoIDFitnesCentra(selektovanaGrupa.FitnesCentar.IdFCentra, selektovanaGrupa.Tip.Kapacitet);

                    TerminDTO termin = new TerminDTO();
                    termin.Koordinator = new KoordinatorDTO();
                    termin.Grupa = new GrupaDTO();
                    termin.DanUSedmici = new DaniDTO();
                    termin.Grupa.IdGrupe = selektovanaGrupa.IdGrupe;
                    termin.Sala = new SalaDTO();


                    termin.Vrijeme = dateTimePicker2.Value.TimeOfDay.ToString();

                    foreach (DaniDTO d in daniUSedmici)
                    {
                        if (d.Naziv.Equals(comboBoxDan.Text))
                        {
                            termin.DanUSedmici.IdDana = d.IdDana;
                        }

                    }

                    foreach (SalaDTO s in sale)
                    {
                        if (("Fitnes centar: " + s.FitnesCentar.IdFCentra + ": sala " + s.IdSale).Equals(comboBoxSala.Text))
                        {
                            termin.Sala.IdSale = s.IdSale;
                        }

                    }

                    foreach (KoordinatorDTO k in koordinatori)
                    {
                        if ((k.Ime + "(" + k.Jmbg + ")").Equals(comboBoxKoordinator.Text))
                        {
                            termin.Koordinator.Jmbg = k.Jmbg;
                        }
                    }

                    if (TrenerDAO.provjeraZauzetostiTerminaZaTrenera(termin.Vrijeme, termin.Grupa.IdGrupe, null, termin.DanUSedmici.IdDana))
                    {
                        MessageBox.Show("Trener je zauzet u odabranom terminu!", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        if (!TerminDAO.dodavanjeTermina(termin))
                        {
                            MessageBox.Show("Uspješno ste dodali termin.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                        else
                            MessageBox.Show("Termin u odabranoj sali je zauzet!", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }

                else
                    MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }



            

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxSala.Text != "") {
                List<SalaDTO> sale = SalaDAO.sveSalePoIDFitnesCentra(selektovanaGrupa.FitnesCentar.IdFCentra, selektovanaGrupa.Tip.Kapacitet);
                foreach (SalaDTO s in sale)
                {
                    if (("Fitnes centar: " + s.FitnesCentar.IdFCentra + ": sala " + s.IdSale).Equals(comboBoxSala.Text))
                    {
                        Sala ss = new Sala(s.IdSale);
                        ss.ShowDialog();

                    }

                }

            }
        }


    }
}
