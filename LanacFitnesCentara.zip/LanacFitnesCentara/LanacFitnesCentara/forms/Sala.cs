﻿using LanacFitnesCentara.db.dto;
using LanacFitnesCentara.db.dao;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class Sala : Form
    {
        private int idSale;

        public Sala(int idSale)
        {
            InitializeComponent();
            this.idSale = idSale;

            dataGridView1.Rows.Clear();
            List<RasporedSaleDTO> raspored = SalaDAO.rasporedSalePoID(idSale);
            
            foreach (RasporedSaleDTO r in raspored)
            {
                dataGridView1.Rows.Add(r.IdSale,r.DanUSedmici,r.VrijemeOd,r.VrijemeDo,r.Grupa);
            }


        }

    }
}
