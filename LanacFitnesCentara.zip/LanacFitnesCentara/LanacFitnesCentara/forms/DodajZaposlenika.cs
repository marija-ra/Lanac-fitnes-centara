﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajZaposlenika : Form
    {
        private bool dodaj;
        private ZaposlenikDTO selektovaniZaposlenik;
        string vrstaZaposlenika = "";

        public DodajZaposlenika(bool dodaj, ZaposlenikDTO zaposlenik, string vrstaZaposlenika)
        {
            InitializeComponent();
            this.dodaj = dodaj;
            this.selektovaniZaposlenik = zaposlenik;
            this.vrstaZaposlenika = vrstaZaposlenika;
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();

            if (dodaj)
            {
                this.Text = "Dodavanje zaposlenika";
                textBoxJMBG.Text = "";
                textBoxIme.Text = "";
                textBoxPrezime.Text = "";
                textBoxAdresa.Text = "";
                textBoxStrucnaSprema.Text = "";

                foreach (MjestoDTO m in mjesta)
                {
                    comboBoxMjesto.Items.Add(m.Naziv);
                }
            }
            else 
            
            {
                this.Text = "Uređivanje zaposlenika";
                
                textBoxJMBG.Text = zaposlenik.Jmbg;
                textBoxIme.Text = zaposlenik.Ime;
                textBoxPrezime.Text = zaposlenik.Prezime;
                textBoxAdresa.Text = zaposlenik.Adresa;
                textBoxStrucnaSprema.Text = zaposlenik.StrucnaSprema;

                int brojac1 = 0;
                int pom1 = 0;

                foreach (MjestoDTO m in mjesta) 
                {
                    comboBoxMjesto.Items.Add(m.Naziv);
                    if(m.IdMjesta == zaposlenik.Mjesto.IdMjesta)
                    {
                        pom1 = brojac1;
                    }
                    brojac1++;
                }
                comboBoxMjesto.SelectedIndex = pom1;
            
            }

        }

        private void buttonDodajMjesto_Click(object sender, EventArgs e)
        {
            DodajMjesto dm = new DodajMjesto(true, null);
            dm.ShowDialog();

            comboBoxMjesto.Items.Clear();
            List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
            foreach (MjestoDTO m in mjesta)
            {
                comboBoxMjesto.Items.Add(m.Naziv);
            }
        }

        private void buttonOdustani_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (textBoxJMBG.Text != "" && textBoxIme.Text != "" && textBoxPrezime.Text != "" && textBoxAdresa.Text != "" && textBoxStrucnaSprema.Text != "" && comboBoxMjesto.Text != "")
            {
                if (dodaj && "treneri".Equals(vrstaZaposlenika) )
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                    TrenerDTO trener = new TrenerDTO();
                    trener.Mjesto = new MjestoDTO();

                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            trener.Jmbg = textBoxJMBG.Text;
                            trener.Ime = textBoxIme.Text;
                            trener.Prezime = textBoxPrezime.Text;
                            trener.Adresa = textBoxAdresa.Text;
                            trener.StrucnaSprema = textBoxStrucnaSprema.Text;
                            trener.Mjesto.IdMjesta = m.IdMjesta;
                            trener.Mjesto.Grad = m.Grad;
                            trener.Mjesto.Naziv = m.Naziv;

                            if(TrenerDAO.dodavanjeTrenera(trener))
                                MessageBox.Show("Uspješno ste dodali trenera.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    

                }
                else if (dodaj == false && "treneri".Equals(vrstaZaposlenika))
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            if(TrenerDAO.uredjivanjeTrenera(textBoxJMBG.Text, textBoxIme.Text, textBoxPrezime.Text, textBoxAdresa.Text, m.IdMjesta, textBoxStrucnaSprema.Text, selektovaniZaposlenik.Jmbg))
                                MessageBox.Show("Uspješno ste uredili trenera.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                   
                }
                else if (dodaj && "koordinatori".Equals(vrstaZaposlenika))
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                    KoordinatorDTO koordinator = new KoordinatorDTO();
                    koordinator.Mjesto = new MjestoDTO();

                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            koordinator.Jmbg = textBoxJMBG.Text;
                            koordinator.Ime = textBoxIme.Text;
                            koordinator.Prezime = textBoxPrezime.Text;
                            koordinator.Adresa = textBoxAdresa.Text;
                            koordinator.StrucnaSprema = textBoxStrucnaSprema.Text;
                            koordinator.Mjesto.IdMjesta = m.IdMjesta;
                            koordinator.Mjesto.Grad = m.Grad;
                            koordinator.Mjesto.Naziv = m.Naziv;

                            if (KoordinatorDAO.dodavanjeKoordinatora(koordinator))
                                MessageBox.Show("Uspješno ste dodali koordinatora.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                else if (dodaj== false && "koordinatori".Equals(vrstaZaposlenika))
                {
                    List<MjestoDTO> mjesta = MjestoDAO.svaMjesta();
                    foreach (MjestoDTO m in mjesta)
                    {
                        if (m.Naziv.Equals(comboBoxMjesto.Text))
                        {
                            if (KoordinatorDAO.uredjivanjeKoordinatora(textBoxJMBG.Text, textBoxIme.Text, textBoxPrezime.Text, textBoxAdresa.Text, m.IdMjesta, textBoxStrucnaSprema.Text, selektovaniZaposlenik.Jmbg))
                                MessageBox.Show("Uspješno ste uredili koordinatora.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }




                this.Close();
            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
