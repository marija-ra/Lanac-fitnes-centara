﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class GrupniTreningTip : Form
    {
        private TipGrupniTreningDTO selektovaniTipTreninga;
        private TipClanarineDTO selektovanTipClanarine;

        public GrupniTreningTip()
        {
            InitializeComponent();
            

            selektovanTipClanarine = null;
            selektovaniTipTreninga = null;

            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();

            popuniDataGrid();

        }


       

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DodajTipGrupniTrening tgt = new DodajTipGrupniTrening(true,null);
            tgt.ShowDialog();
            popuniDataGrid();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                if (TipGrupniTreningDAO.brisanjeTipaGrupnogTreninga(selektovaniTipTreninga.IdTipaTreninga))
                    MessageBox.Show("Uspješno ste obrisali tip grupnog treninga : " + selektovaniTipTreninga.Naziv, "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte tip koji želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                DodajTipGrupniTrening tgt = new DodajTipGrupniTrening(false, selektovaniTipTreninga);
                tgt.ShowDialog();
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte člana kojeg želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void buttonPregledajGrupe_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                Grupe g = new Grupe(selektovaniTipTreninga.IdTipaTreninga);
                g.ShowDialog();
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            


        }

        private void buttonDodajTipClanarine_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                DodajTipClanarine tc = new DodajTipClanarine(selektovaniTipTreninga.IdTipaTreninga);
                tc.ShowDialog();

                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte tip koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        public void popuniDataGrid()
        {
            dataGridView1.Rows.Clear();
            List<TipGrupniTreningDTO> tipovi = TipGrupniTreningDAO.sviTipoviGrupniTrening();
            foreach (TipGrupniTreningDTO tip in tipovi)
            {
                dataGridView1.Rows.Add(tip.IdTipaTreninga, tip.Naziv, tip.TrajanjeUMinutama, tip.Kapacitet);
            }

            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                int IdTipaTreninga = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["IDTipa"].Value);
                selektovaniTipTreninga = TipGrupniTreningDAO.tipGrupnogTreningaPoID(IdTipaTreninga);
                popuniDataGridTipClanarina();
            }
            else
                selektovaniTipTreninga = null;
        }

        public void popuniDataGridTipClanarina()
        {
            dataGridView2.Rows.Clear();

            List<TipClanarineDTO> tipoviClanarina = TipClanarineDAO.sviTipoviClanarinaPoIDTipuTreninga(selektovaniTipTreninga.IdTipaTreninga);
            foreach (TipClanarineDTO tip in tipoviClanarina)
            {
                dataGridView2.Rows.Add(tip.IdTipaClanarine, tip.Naziv, tip.Cijena);
            }

            if (dataGridView2.RowCount != 0)
            {
                dataGridView2.Rows[0].Selected = true;
                int IDTipaClanarine = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTipaClanarine"].Value);
                selektovanTipClanarine = TipClanarineDAO.tipClanarinePoID(IDTipaClanarine);
            }
            else
                selektovanTipClanarine = null;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int idTipa = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["IDTipa"].Value);
                selektovaniTipTreninga = TipGrupniTreningDAO.tipGrupnogTreningaPoID(idTipa);
                popuniDataGridTipClanarina();
            }
            else
            {
                MessageBox.Show("Selektujte tip koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 1)
            {
                int idTipaClanarine = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTipaClanarine"].Value);
                selektovanTipClanarine = TipClanarineDAO.tipClanarinePoID(idTipaClanarine);
            }
            else
            {
                MessageBox.Show("Selektujte termin koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonZatvori_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
