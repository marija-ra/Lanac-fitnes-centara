﻿using LanacFitnesCentara.db.dao;

using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class Zaposleni : Form

    {
        private TrenerDTO selektovaniTrener;
        private KoordinatorDTO selektovaniKoordinator;
        string vrstaZaposlenika = "";

        public Zaposleni(string vrsta)
        {
            InitializeComponent();
            vrstaZaposlenika = vrsta;
            popuniDataGrid();

        }

        public void popuniDataGrid()
        {
            if ("treneri".Equals(vrstaZaposlenika))
            {
                dataGridView1.Rows.Clear();
                List<TrenerDTO> treneri = TrenerDAO.sviTreneri();
                foreach (TrenerDTO trener in treneri)
                {
                    dataGridView1.Rows.Add(trener.Jmbg, trener.Ime, trener.Prezime, trener.Adresa, trener.StrucnaSprema, trener.Mjesto.Grad, trener.Mjesto.Naziv);
                }

                if (dataGridView1.RowCount != 0)
                {
                    dataGridView1.Rows[0].Selected = true;
                    string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                    selektovaniTrener = TrenerDAO.trenerPoJMBG(jmbg);
                }
                else
                    selektovaniTrener = null;
            }

            else if ("koordinatori".Equals(vrstaZaposlenika))
            {
                dataGridView1.Rows.Clear();
                List<KoordinatorDTO> koordinatori = KoordinatorDAO.sviKoordinatori();
                foreach (KoordinatorDTO koordinator in koordinatori)
                {
                    dataGridView1.Rows.Add(koordinator.Jmbg, koordinator.Ime, koordinator.Prezime, koordinator.Adresa, koordinator.StrucnaSprema, koordinator.Mjesto.Grad, koordinator.Mjesto.Naziv);
                }

                if (dataGridView1.RowCount != 0)
                {
                    dataGridView1.Rows[0].Selected = true;
                    string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                    selektovaniKoordinator = KoordinatorDAO.koordinatorPoJMBG(jmbg);
                }
                else
                    selektovaniKoordinator = null;
              
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

            DodajZaposlenika dc = new DodajZaposlenika(true, null, vrstaZaposlenika);
            dc.ShowDialog();
            popuniDataGrid();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if("treneri".Equals(vrstaZaposlenika))
            {
                if (selektovaniTrener != null)
                {
                    if(TrenerDAO.brisanjeTrenera(selektovaniTrener.Jmbg))
                        MessageBox.Show("Uspješno ste obrisali zaposlenika : " + selektovaniTrener.Ime + " " + selektovaniTrener.Prezime, "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    popuniDataGrid();
                }
                else
                     MessageBox.Show("Selektujte trenera kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if("koordinatori".Equals(vrstaZaposlenika))
            {
                if (selektovaniKoordinator != null)
                {
                    if(KoordinatorDAO.brisanjeKoordinatora(selektovaniKoordinator.Jmbg))
                        MessageBox.Show("Uspješno ste obrisali koordinatora : " + selektovaniKoordinator.Ime + " " + selektovaniKoordinator.Prezime, "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    popuniDataGrid();
                }
                else
                     MessageBox.Show("Selektujte koordinatora kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (selektovaniTrener != null && "treneri".Equals(vrstaZaposlenika))
            {
                DodajZaposlenika dc = new DodajZaposlenika(false, selektovaniTrener, vrstaZaposlenika);
                dc.ShowDialog();
                popuniDataGrid();
            }

            else if (selektovaniKoordinator != null && "koordinatori".Equals(vrstaZaposlenika))
            {
                DodajZaposlenika dc = new DodajZaposlenika(false, selektovaniKoordinator, vrstaZaposlenika);
                dc.ShowDialog();
                popuniDataGrid();
            }
            else 
                MessageBox.Show("Selektujte zaposlenika kojeg želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                

                if ("treneri".Equals(vrstaZaposlenika))
                {
                    string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                    selektovaniTrener = TrenerDAO.trenerPoJMBG(jmbg);
                    selektovaniKoordinator = null;
                }
                    
                else if ("koordinatori".Equals(vrstaZaposlenika))
                {
                    string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                    selektovaniKoordinator = KoordinatorDAO.koordinatorPoJMBG(jmbg);
                    selektovaniTrener = null;
                }                  
            
            }
            else
            {
                MessageBox.Show("Selektujte člana kojeg želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
