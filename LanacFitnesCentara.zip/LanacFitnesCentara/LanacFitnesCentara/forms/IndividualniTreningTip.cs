﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class IndividualniTreningTip : Form
    {
        private TipIndividualniTreningDTO selektovaniTipTreninga;
        private TipClanarineDTO selektovanTipClanarine;

        public IndividualniTreningTip()
        {
            InitializeComponent();
            selektovanTipClanarine = null;
            selektovaniTipTreninga = null;

            dataGridView1.Rows.Clear();
            dataGridView2.Rows.Clear();

            popuniDataGrid();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DodajTipIndividualniTrening tit = new DodajTipIndividualniTrening(true,null);
            tit.ShowDialog();
            popuniDataGrid();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                if (TipIndividualniTreningDAO.brisanjeTipaIndividualnogTreninga(selektovaniTipTreninga.IdTipaTreninga))
                    MessageBox.Show("Uspješno ste obrisali tip individualnog treninga : " + selektovaniTipTreninga.Naziv, "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte tip koji želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                DodajTipIndividualniTrening tit = new DodajTipIndividualniTrening(false, selektovaniTipTreninga);
                tit.ShowDialog();
                popuniDataGrid();
            }
        }

        private void buttonPregledajGrupe_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                //Grupe g = new Grupe(selektovaniTipTreninga.IdTipaTreninga);
                //g.ShowDialog();
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);




        }

        private void buttonDodajTipClanarine_Click(object sender, EventArgs e)
        {

          if (selektovaniTipTreninga != null)
            {
                DodajTipClanarine tc = new DodajTipClanarine(selektovaniTipTreninga.IdTipaTreninga);
                tc.ShowDialog();

                popuniDataGrid();
            }
          else
              MessageBox.Show("Selektujte tip koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        public void popuniDataGrid()
        {
            dataGridView1.Rows.Clear();
            List<TipIndividualniTreningDTO> tipovi = TipIndividualniTreningDAO.sviTipoviIndividualniTrening();
            foreach (TipIndividualniTreningDTO tip in tipovi)
            {
                dataGridView1.Rows.Add(tip.IdTipaTreninga, tip.Naziv, tip.TrajanjeUMinutama);
            }

            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                int IdTipaTreninga = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["IDTipa"].Value);
                selektovaniTipTreninga = TipIndividualniTreningDAO.tipIndividualnogTreningaPoID(IdTipaTreninga);
                popuniDataGridTipClanarina();
            }
            else
                selektovaniTipTreninga = null;
        }

        public void popuniDataGridTipClanarina()
        {
            dataGridView2.Rows.Clear();

            List<TipClanarineDTO> tipoviClanarina = TipClanarineDAO.sviTipoviClanarinaPoIDTipuTreninga(selektovaniTipTreninga.IdTipaTreninga);
            foreach (TipClanarineDTO tip in tipoviClanarina)
            {
                dataGridView2.Rows.Add(tip.IdTipaClanarine, tip.Naziv, tip.Cijena);
            }

            if (dataGridView2.RowCount != 0)
            {
                dataGridView2.Rows[0].Selected = true;
                int IDTipaClanarine = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTipaClanarine"].Value);
                selektovanTipClanarine = TipClanarineDAO.tipClanarinePoID(IDTipaClanarine);
            }
            else
                selektovanTipClanarine = null;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int idTipa = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["IDTipa"].Value);
                selektovaniTipTreninga = TipIndividualniTreningDAO.tipIndividualnogTreningaPoID(idTipa);
                popuniDataGridTipClanarina();
            }
            else
            {
                MessageBox.Show("Selektujte tip koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 1)
            {
                int idTipaClanarine = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTipaClanarine"].Value);
                selektovanTipClanarine = TipClanarineDAO.tipClanarinePoID(idTipaClanarine);
            }
            else
            {
                MessageBox.Show("Selektujte termin koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonZatvori_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonPregledajIndividualneTreninge_Click(object sender, EventArgs e)
        {
            if (selektovaniTipTreninga != null)
            {
                IndividualniTreninzi g = new IndividualniTreninzi(selektovaniTipTreninga.IdTipaTreninga);
                g.ShowDialog();
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte grupu koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        


    }
}
