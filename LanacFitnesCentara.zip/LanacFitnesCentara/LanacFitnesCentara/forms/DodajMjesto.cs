﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class DodajMjesto : Form
    {
        private bool dodaj;
        public static int brojMjesta = 0;

        public DodajMjesto(bool dodaj, MjestoDTO mjesto)
        {
            
            InitializeComponent();
            this.dodaj = dodaj;


            if (dodaj)
            {
                this.Text = "Dodavanje mjesta";
                textBoxGrad.Text = "";
                textBoxRegija.Text = "";
                textBoxNaziv.Text = "";
                
            }

        }

        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (textBoxGrad.Text != "" && textBoxRegija.Text != "" && textBoxNaziv.Text != "" )
            {
                if (dodaj)
                {

                    
                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.Grad = textBoxGrad.Text;
                    mjesto.Regija = textBoxRegija.Text;
                    mjesto.Naziv = textBoxNaziv.Text;

                    MjestoDAO.dodavanjeMjesta(mjesto);

                    
                                        
                    MessageBox.Show("Uspješno ste dodali mjesto.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                { /*
                    List<KursDTO> kursevi = KursDAO.listaSvihKurseva();
                    int idKursa = 0;
                    foreach (KursDTO k in kursevi)
                    {
                        if (k.Naziv.Equals(comboBoxKurs.Text))
                            idKursa = k.idKurs;
                    }

                    List<InstruktorDTO> instrutkori = InstruktorDAO.listaSvihInstruktora();
                    foreach (InstruktorDTO i in instrutkori)
                    {
                        string pom = i.Ime + " " + i.Prezime;
                        if (pom.Equals(comboBoxInstruktor.Text))
                        {
                            ClanDAO.urediClan(selektovaniClan.IdClana, textBoxIme.Text, textBoxPrezime.Text, textBoxAdresa.Text, i.IdInstruktor, idKursa);
                        }
                    }
                    MessageBox.Show("Uspješno ste uredili člana.", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    */
                }

                this.Close();
            }
            else
            {
                MessageBox.Show("Popunite sve podatke", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
