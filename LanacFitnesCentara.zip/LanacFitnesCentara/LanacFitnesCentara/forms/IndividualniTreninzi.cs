﻿using LanacFitnesCentara.db.dao;
using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class IndividualniTreninzi : Form
    {
        int idTipaIndividualnogTreninga;

        private IndividualniTreningDTO selektovanIndTrening;
        private TerminDTO selektovanTermin;
        private TipIndividualniTreningDTO tip;

        public IndividualniTreninzi(int idTipaIndividualnogTreninga)
        {
            InitializeComponent();
            this.idTipaIndividualnogTreninga = idTipaIndividualnogTreninga;
            tip = TipIndividualniTreningDAO.tipIndividualnogTreningaPoID(idTipaIndividualnogTreninga);
            selektovanIndTrening = null;
            selektovanTermin = null;
            textBoxOpisTipaGrupe.Text = tip.OpisTreninga;

            dataGridView2.Rows.Clear();
            popuniDataGrid();
        }

                
        public void popuniDataGrid()
        {
            dataGridView1.Rows.Clear();
            List<IndividualniTreningDTO> individualniTreninzi = IndividualniTreningDAO.sviIndividualniTreninziTipa(idTipaIndividualnogTreninga);
            List<IndividualniTreningDTO> aktivniIndividualniTreninzi = IndividualniTreningDAO.sviAktivniIndividualniTreninzi();

            foreach (IndividualniTreningDTO trening in individualniTreninzi)
            {

                ClanDTO clan = ClanDAO.clanPoJMBG(trening.Clan.Jmbg);
                dataGridView1.Rows.Add(trening.IdIndividualnogTreninga, trening.Tip.Naziv, trening.Tip.TrajanjeUMinutama, clan.Ime, clan.jmbg, trening.Trener.Ime, trening.Trener.Jmbg);
            }


            foreach (DataGridViewRow gridRow in dataGridView1.Rows)
            {

                bool aktivan = aktivniIndividualniTreninzi.Any(trening => trening.IdIndividualnogTreninga == Convert.ToInt32(gridRow.Cells["idIndTreninga"].Value));
                if (!aktivan)
                    gridRow.DefaultCellStyle.BackColor = Color.Gray;

            }

            
            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                int idTreninga = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idIndTreninga"].Value);
                selektovanIndTrening = IndividualniTreningDAO.individualniTreningPoID(idTreninga);
                popuniDataGridTermini(selektovanIndTrening.IdIndividualnogTreninga);
            }
            else
                selektovanIndTrening = null;
        }

        public void popuniDataGridTermini(int idTipaIndividualnogTreninga)
        {
            dataGridView2.Rows.Clear();
            List<TerminDTO> termini = TerminDAO.sviTerminiPoIDIndividualniTrening(idTipaIndividualnogTreninga);

            foreach (TerminDTO termin in termini)
            {
                dataGridView2.Rows.Add(termin.IdTermina, termin.DanUSedmici.Naziv, termin.Vrijeme);
            }

            if (dataGridView2.RowCount != 0)
            {
                dataGridView2.Rows[0].Selected = true;
                int IDTermina = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTermina"].Value);
                selektovanTermin = TerminDAO.terminPoID(IDTermina);

            }
            else
                selektovanTermin = null;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int idTreninga = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["idIndTreninga"].Value);
                selektovanIndTrening = IndividualniTreningDAO.individualniTreningPoID(idTreninga);
                popuniDataGridTermini(selektovanIndTrening.IdIndividualnogTreninga);
            }
            else
            {
                MessageBox.Show("Selektujte trening koju želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.SelectedRows.Count == 1)
            {
                int idTermina = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IDTermina"].Value);
                selektovanTermin = TerminDAO.terminPoID(idTermina);
            }
            else
            {
                MessageBox.Show("Selektujte termin koji želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }       

        private void buttonZatvori_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonObrisiTermin_Click(object sender, EventArgs e)
        {
            if (selektovanTermin != null)
            {
                if (TerminDAO.brisanjeTermina(selektovanTermin.IdTermina))
                    MessageBox.Show("Uspješno ste obrisali termin", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte termin kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void buttonDodajNoviTermin_Click(object sender, EventArgs e)
        {
            string vrstaTermina = "individualni";
            DodajTermin dt = new DodajTermin(vrstaTermina,null, selektovanIndTrening.IdIndividualnogTreninga);
            dt.ShowDialog();
            popuniDataGrid();
            if (selektovanIndTrening != null)
                popuniDataGridTermini(selektovanIndTrening.IdIndividualnogTreninga);

        }
        
    }
}
