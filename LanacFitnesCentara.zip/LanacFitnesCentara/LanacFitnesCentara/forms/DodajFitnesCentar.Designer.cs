﻿namespace LanacFitnesCentara.forms
{
    partial class DodajFitnesCentar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajFitnesCentar));
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxRadnoVrijeme = new System.Windows.Forms.TextBox();
            this.comboBoxMjesto = new System.Windows.Forms.ComboBox();
            this.buttonSacuvaj = new System.Windows.Forms.Button();
            this.buttonOdustani = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonDodajMjesto = new System.Windows.Forms.Button();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxZaposleni = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label1.Location = new System.Drawing.Point(23, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Radno vrijeme:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label4.Location = new System.Drawing.Point(23, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mjesto:";
            // 
            // textBoxRadnoVrijeme
            // 
            this.textBoxRadnoVrijeme.Location = new System.Drawing.Point(121, 57);
            this.textBoxRadnoVrijeme.Name = "textBoxRadnoVrijeme";
            this.textBoxRadnoVrijeme.Size = new System.Drawing.Size(158, 20);
            this.textBoxRadnoVrijeme.TabIndex = 4;
            // 
            // comboBoxMjesto
            // 
            this.comboBoxMjesto.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxMjesto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMjesto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxMjesto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxMjesto.FormattingEnabled = true;
            this.comboBoxMjesto.Location = new System.Drawing.Point(121, 100);
            this.comboBoxMjesto.Name = "comboBoxMjesto";
            this.comboBoxMjesto.Size = new System.Drawing.Size(158, 21);
            this.comboBoxMjesto.TabIndex = 51;
            // 
            // buttonSacuvaj
            // 
            this.buttonSacuvaj.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonSacuvaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSacuvaj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSacuvaj.Location = new System.Drawing.Point(121, 260);
            this.buttonSacuvaj.Name = "buttonSacuvaj";
            this.buttonSacuvaj.Size = new System.Drawing.Size(75, 23);
            this.buttonSacuvaj.TabIndex = 100;
            this.buttonSacuvaj.Text = "Sačuvaj";
            this.buttonSacuvaj.UseVisualStyleBackColor = false;
            this.buttonSacuvaj.Click += new System.EventHandler(this.buttonSacuvaj_Click);
            // 
            // buttonOdustani
            // 
            this.buttonOdustani.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonOdustani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOdustani.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonOdustani.Location = new System.Drawing.Point(204, 260);
            this.buttonOdustani.Name = "buttonOdustani";
            this.buttonOdustani.Size = new System.Drawing.Size(75, 23);
            this.buttonOdustani.TabIndex = 101;
            this.buttonOdustani.Text = "Odustani";
            this.buttonOdustani.UseVisualStyleBackColor = false;
            this.buttonOdustani.Click += new System.EventHandler(this.buttonOdustani_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 102;
            this.label6.Text = "Email:";
            // 
            // buttonDodajMjesto
            // 
            this.buttonDodajMjesto.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonDodajMjesto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDodajMjesto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDodajMjesto.Location = new System.Drawing.Point(26, 259);
            this.buttonDodajMjesto.Name = "buttonDodajMjesto";
            this.buttonDodajMjesto.Size = new System.Drawing.Size(89, 23);
            this.buttonDodajMjesto.TabIndex = 80;
            this.buttonDodajMjesto.Text = "Dodaj Mjesto";
            this.buttonDodajMjesto.UseVisualStyleBackColor = false;
            this.buttonDodajMjesto.Click += new System.EventHandler(this.buttonDodajMjesto_Click);
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(121, 23);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(158, 20);
            this.textBoxEmail.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.label2.Location = new System.Drawing.Point(23, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 103;
            this.label2.Text = "Direktor:";
            // 
            // comboBoxZaposleni
            // 
            this.comboBoxZaposleni.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxZaposleni.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxZaposleni.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxZaposleni.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxZaposleni.FormattingEnabled = true;
            this.comboBoxZaposleni.Location = new System.Drawing.Point(121, 142);
            this.comboBoxZaposleni.Name = "comboBoxZaposleni";
            this.comboBoxZaposleni.Size = new System.Drawing.Size(158, 21);
            this.comboBoxZaposleni.TabIndex = 104;
            // 
            // DodajFitnesCentar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(305, 314);
            this.Controls.Add(this.comboBoxZaposleni);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.buttonDodajMjesto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonOdustani);
            this.Controls.Add(this.buttonSacuvaj);
            this.Controls.Add(this.comboBoxMjesto);
            this.Controls.Add(this.textBoxRadnoVrijeme);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DodajFitnesCentar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodaj fitnes centar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxRadnoVrijeme;
        private System.Windows.Forms.ComboBox comboBoxMjesto;
        private System.Windows.Forms.Button buttonSacuvaj;
        private System.Windows.Forms.Button buttonOdustani;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonDodajMjesto;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxZaposleni;
    }
}