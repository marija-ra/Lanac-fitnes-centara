﻿using LanacFitnesCentara.db.dao;

using LanacFitnesCentara.db.dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.forms
{
    public partial class Clanovi : Form
    {
        private ClanDTO selektovaniClan;
        private ClanarinaDTO selektovanaClanarina;

        public Clanovi()
        {
            InitializeComponent();
            popuniDataGrid();
        }

        public void popuniDataGrid()
        {
            dataGridView1.Rows.Clear();
            List<ClanDTO> clanovi = ClanDAO.sviClanovi();
            foreach (ClanDTO clan in clanovi)
            {
                dataGridView1.Rows.Add(clan.Jmbg,clan.Ime, clan.Prezime, clan.Adresa, clan.ClanskiBroj, clan.Mjesto.Grad, clan.Mjesto.Naziv);
            }

            if (dataGridView1.RowCount != 0)
            {
                dataGridView1.Rows[0].Selected = true;
                string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                selektovaniClan = ClanDAO.clanPoJMBG(jmbg);

                popuniDataGridClanarine();
            }
            else
                selektovaniClan = null;
        }

        public void popuniDataGridClanarine()
        {
            if (selektovaniClan != null)
            {

                dataGridView2.Rows.Clear();
                List<ClanarinaDTO> clanarine = ClanarinaDAO.sveClanarinePoClanuJMBBG(selektovaniClan.Jmbg);
                foreach (ClanarinaDTO c in clanarine)
                {
                    dataGridView2.Rows.Add(c.IdClanarine, c.TipClanarine.Naziv, c.TipClanarine.Cijena, c.DatumPrijave, c.DatumIsteka, c.TipClanarine.TipTreninga.Naziv);
                }

                foreach (DataGridViewRow gridRow in dataGridView2.Rows)
                {
                    DateTime dateumIsteka = Convert.ToDateTime(gridRow.Cells["ColumnDatumIsteka"].Value);
                    DateTime danasnjiDatum = DateTime.Now;;

                    if (dateumIsteka.Date < danasnjiDatum.Date)
                    {
                        gridRow.DefaultCellStyle.BackColor = Color.Gray;
                    }

                }


                if (dataGridView2.RowCount != 0)
                {
                    dataGridView2.Rows[0].Selected = true;
                    
                    int idClanarine = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["IdClanarine"].Value);
                    selektovanaClanarina = ClanarinaDAO.clanarinaPoID(idClanarine);
                }
                else
                    selektovanaClanarina = null;
            }
            
        }

        public void toolStripButton1_Click(object sender, EventArgs e)
        {
            DodajClana dc = new DodajClana(true, null);
            dc.ShowDialog();
            popuniDataGrid();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (selektovaniClan != null)
            {
                if(ClanDAO.brisanjeClana(selektovaniClan.Jmbg))
                    MessageBox.Show("Uspješno ste obrisali člana : " + selektovaniClan.Ime + " " + selektovaniClan.Prezime, "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte člana kojeg želite obrisati", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (selektovaniClan != null)
            {
                DodajClana dc = new DodajClana(false, selektovaniClan);
                dc.ShowDialog();
                popuniDataGrid();
            }
            else
                MessageBox.Show("Selektujte člana kojeg želite urediti", "Poruka", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                string jmbg = Convert.ToString(dataGridView1.SelectedRows[0].Cells["ColumnJMBG"].Value);
                selektovaniClan = ClanDAO.clanPoJMBG(jmbg);
                popuniDataGridClanarine();

            }
            else
            {
                selektovaniClan = null;
                dataGridView2.Rows.Clear();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DodajClanarinu dc = new DodajClanarinu(selektovaniClan);
            dc.ShowDialog();
            popuniDataGrid();
        }

        private void buttonIndividualniTren_Click(object sender, EventArgs e)
        {
            DodajIndividualniTrening clanarinaZaIndividualniTrening = new DodajIndividualniTrening(selektovaniClan);
            clanarinaZaIndividualniTrening.ShowDialog();
            popuniDataGrid();
        }

        
    }
}
