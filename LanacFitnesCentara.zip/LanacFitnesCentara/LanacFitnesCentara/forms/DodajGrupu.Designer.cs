﻿namespace LanacFitnesCentara.forms
{
    partial class DodajGrupu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajGrupu));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxTipGrupnogTreninga = new System.Windows.Forms.ComboBox();
            this.buttonSacuvaj = new System.Windows.Forms.Button();
            this.buttonOdustani = new System.Windows.Forms.Button();
            this.buttonDodajTipGrupnogTreninga = new System.Windows.Forms.Button();
            this.comboBoxTrener = new System.Windows.Forms.ComboBox();
            this.buttonDodajTrenera = new System.Windows.Forms.Button();
            this.comboBoxFitnesCentar = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonDodajFitnesCentar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(23, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tip grupnog treninga :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(23, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Trener:";
            // 
            // comboBoxTipGrupnogTreninga
            // 
            this.comboBoxTipGrupnogTreninga.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxTipGrupnogTreninga.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTipGrupnogTreninga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTipGrupnogTreninga.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxTipGrupnogTreninga.FormattingEnabled = true;
            this.comboBoxTipGrupnogTreninga.Location = new System.Drawing.Point(26, 56);
            this.comboBoxTipGrupnogTreninga.Name = "comboBoxTipGrupnogTreninga";
            this.comboBoxTipGrupnogTreninga.Size = new System.Drawing.Size(158, 21);
            this.comboBoxTipGrupnogTreninga.TabIndex = 51;
            // 
            // buttonSacuvaj
            // 
            this.buttonSacuvaj.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonSacuvaj.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSacuvaj.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonSacuvaj.Location = new System.Drawing.Point(178, 251);
            this.buttonSacuvaj.Name = "buttonSacuvaj";
            this.buttonSacuvaj.Size = new System.Drawing.Size(75, 23);
            this.buttonSacuvaj.TabIndex = 100;
            this.buttonSacuvaj.Text = "Sačuvaj";
            this.buttonSacuvaj.UseVisualStyleBackColor = false;
            this.buttonSacuvaj.Click += new System.EventHandler(this.buttonSacuvaj_Click);
            // 
            // buttonOdustani
            // 
            this.buttonOdustani.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonOdustani.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOdustani.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonOdustani.Location = new System.Drawing.Point(259, 251);
            this.buttonOdustani.Name = "buttonOdustani";
            this.buttonOdustani.Size = new System.Drawing.Size(75, 23);
            this.buttonOdustani.TabIndex = 101;
            this.buttonOdustani.Text = "Odustani";
            this.buttonOdustani.UseVisualStyleBackColor = false;
            this.buttonOdustani.Click += new System.EventHandler(this.buttonOdustani_Click);
            // 
            // buttonDodajTipGrupnogTreninga
            // 
            this.buttonDodajTipGrupnogTreninga.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonDodajTipGrupnogTreninga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDodajTipGrupnogTreninga.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDodajTipGrupnogTreninga.Location = new System.Drawing.Point(190, 56);
            this.buttonDodajTipGrupnogTreninga.Name = "buttonDodajTipGrupnogTreninga";
            this.buttonDodajTipGrupnogTreninga.Size = new System.Drawing.Size(143, 23);
            this.buttonDodajTipGrupnogTreninga.TabIndex = 80;
            this.buttonDodajTipGrupnogTreninga.Text = "Dodaj tip grupnog treninga";
            this.buttonDodajTipGrupnogTreninga.UseVisualStyleBackColor = false;
            this.buttonDodajTipGrupnogTreninga.Click += new System.EventHandler(this.buttonDodajTipGrupnogTreninga_Click);
            // 
            // comboBoxTrener
            // 
            this.comboBoxTrener.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxTrener.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTrener.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxTrener.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxTrener.FormattingEnabled = true;
            this.comboBoxTrener.Location = new System.Drawing.Point(26, 122);
            this.comboBoxTrener.Name = "comboBoxTrener";
            this.comboBoxTrener.Size = new System.Drawing.Size(158, 21);
            this.comboBoxTrener.TabIndex = 102;
            // 
            // buttonDodajTrenera
            // 
            this.buttonDodajTrenera.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonDodajTrenera.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDodajTrenera.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDodajTrenera.Location = new System.Drawing.Point(190, 122);
            this.buttonDodajTrenera.Name = "buttonDodajTrenera";
            this.buttonDodajTrenera.Size = new System.Drawing.Size(89, 23);
            this.buttonDodajTrenera.TabIndex = 103;
            this.buttonDodajTrenera.Text = "Dodaj trenera";
            this.buttonDodajTrenera.UseVisualStyleBackColor = false;
            this.buttonDodajTrenera.Click += new System.EventHandler(this.buttonDodajTrenera_Click);
            // 
            // comboBoxFitnesCentar
            // 
            this.comboBoxFitnesCentar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.comboBoxFitnesCentar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFitnesCentar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxFitnesCentar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comboBoxFitnesCentar.FormattingEnabled = true;
            this.comboBoxFitnesCentar.Location = new System.Drawing.Point(26, 182);
            this.comboBoxFitnesCentar.Name = "comboBoxFitnesCentar";
            this.comboBoxFitnesCentar.Size = new System.Drawing.Size(158, 21);
            this.comboBoxFitnesCentar.TabIndex = 105;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(23, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 104;
            this.label3.Text = "Fitnes centar:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonDodajFitnesCentar
            // 
            this.buttonDodajFitnesCentar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.buttonDodajFitnesCentar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDodajFitnesCentar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.buttonDodajFitnesCentar.Location = new System.Drawing.Point(190, 180);
            this.buttonDodajFitnesCentar.Name = "buttonDodajFitnesCentar";
            this.buttonDodajFitnesCentar.Size = new System.Drawing.Size(89, 23);
            this.buttonDodajFitnesCentar.TabIndex = 106;
            this.buttonDodajFitnesCentar.Text = "Dodaj fitnes centar";
            this.buttonDodajFitnesCentar.UseVisualStyleBackColor = false;
            this.buttonDodajFitnesCentar.Click += new System.EventHandler(this.buttonDodajFitnesCentar_Click);
            // 
            // DodajGrupu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(361, 300);
            this.Controls.Add(this.buttonDodajFitnesCentar);
            this.Controls.Add(this.comboBoxFitnesCentar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buttonDodajTrenera);
            this.Controls.Add(this.comboBoxTrener);
            this.Controls.Add(this.buttonDodajTipGrupnogTreninga);
            this.Controls.Add(this.buttonOdustani);
            this.Controls.Add(this.buttonSacuvaj);
            this.Controls.Add(this.comboBoxTipGrupnogTreninga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DodajGrupu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dodaj Grupu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxTipGrupnogTreninga;
        private System.Windows.Forms.Button buttonSacuvaj;
        private System.Windows.Forms.Button buttonOdustani;
        private System.Windows.Forms.Button buttonDodajTipGrupnogTreninga;
        private System.Windows.Forms.ComboBox comboBoxTrener;
        private System.Windows.Forms.Button buttonDodajTrenera;
        private System.Windows.Forms.ComboBox comboBoxFitnesCentar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonDodajFitnesCentar;
    }
}