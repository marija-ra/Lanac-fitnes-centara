﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db
{
    class ConnectionPool
    {

        private static ArrayList connections;
        private static int connectionNumber = 10;
        private static string server = "localhost";
        private static string database = "fitnesstudio";
        private static string uid = "root";
        private static string password = "student";
        private static string connectionString = connectionString = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
        static ConnectionPool()
        {
            try
            {
                connections = new ArrayList();
                for (int i = 0; i < connectionNumber; i++)
                {
                    MySqlConnection conn = new MySqlConnection(connectionString);
                    conn.Open();
                    MySqlCommand comm = conn.CreateCommand();
                    comm.CommandText = "set collation_connection='utf_unicode_ci'";
                    comm.ExecuteNonQuery();
                    connections.Add(conn);
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.StackTrace);
            }
        }

        public static MySqlConnection getSingleConnection()
        {
            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            return conn;
        }

        public static void closeSingleConnection(MySqlConnection conn)
        {
            conn.Close();
        }

        public static MySqlConnection checkOutConnection()
        {
            foreach (MySqlConnection conn in connections)
            {
                if (conn.State == ConnectionState.Open)
                {
                    connections.Remove(conn);
                    return conn;
                }
            }
            MySqlConnection fallback = getSingleConnection();
            return fallback;
        }

        public static void checkInConnection(MySqlConnection conn)
        {
            connections.Add(conn);
        }
    }
}
