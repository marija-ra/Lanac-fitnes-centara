﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class KoordinatorDAO
    {
        public static List<KoordinatorDTO> sviKoordinatori()
        {
            String upit = "select * from koordinatori_pogled";
            List<KoordinatorDTO> lista = new List<KoordinatorDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    KoordinatorDTO novi = new KoordinatorDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }


        public static KoordinatorDTO koordinatorPoJMBG(string jmbg)
        {
            String upit = "select * from koordinatori_pogled where JMBG=?jmbg";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("jmbg", jmbg);
            MySqlDataReader r = null;
            KoordinatorDTO novi = new KoordinatorDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeKoordinatora(KoordinatorDTO k)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodajKoordinatora('" + k.Jmbg + "','" + k.Ime + "','" + k.Prezime + "','" + k.Adresa + "','" + k.Mjesto.IdMjesta + "','" + k.StrucnaSprema + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeKoordinatora(string jmbg, string ime, string prezime, string adresa, int idMjesta, string strucnaSprema, string stariJMBG)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL urediKoordinatora('" + jmbg + "','" + ime + "','" + prezime + "','" + adresa + "','" + idMjesta + "','" + strucnaSprema + "','" + stariJMBG + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeKoordinatora(string jmbg)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "CALL brisanjeZaposlenika('" + jmbg + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
    }
}
