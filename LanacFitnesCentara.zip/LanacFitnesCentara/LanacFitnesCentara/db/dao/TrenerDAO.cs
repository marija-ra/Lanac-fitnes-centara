﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TrenerDAO
    {
        public static List<TrenerDTO> sviTreneri()
        {
            String upit = "select * from treneri_pogled";
            List<TrenerDTO> lista = new List<TrenerDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    TrenerDTO novi = new TrenerDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }
      

        public static TrenerDTO trenerPoJMBG(string jmbg)
        {
            String upit = "select * from treneri_pogled where JMBG=?jmbg";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("jmbg", jmbg);
            MySqlDataReader r = null;
            TrenerDTO novi = new TrenerDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeTrenera(TrenerDTO t)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodajTrenera('" + t.Jmbg + "','" + t.Ime + "','" + t.Prezime + "','" + t.Adresa + "','" + t.Mjesto.IdMjesta + "','" + t.StrucnaSprema + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeTrenera(string jmbg, string ime, string prezime, string adresa, int idMjesta, string strucnaSprema, string stariJMBG)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL urediTrenera('" + jmbg + "','" + ime + "','" + prezime + "','" + adresa + "','" + idMjesta + "','" + strucnaSprema + "','" + stariJMBG + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeTrenera(string jmbg)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "CALL brisanjeZaposlenika('" + jmbg + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }


        public static bool provjeraZauzetostiTerminaZaTrenera(string vrijemeOd, int? idGrupe, int? idIndTreninga, int idDana)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool zauzetTermin = false;

            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = new MySqlCommand();
                comm.Connection = conn;
                comm.CommandText = "provjeraZauzetostiTerminaZaTrenera";
                comm.CommandType = CommandType.StoredProcedure;

                comm.Parameters.AddWithValue("@vrijemeOd", vrijemeOd);
                comm.Parameters.AddWithValue("@idGrupe", idGrupe);
                comm.Parameters.AddWithValue("@idIndTreninga", idIndTreninga);
                comm.Parameters.AddWithValue("@idDana", idDana);
                comm.Parameters.AddWithValue("@zauzetTermin", MySqlDbType.Bit);
                comm.Parameters["@zauzetTermin"].Direction = ParameterDirection.Output;


                comm.ExecuteNonQuery();

                zauzetTermin = Convert.ToBoolean(comm.Parameters["@zauzetTermin"].Value);
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return zauzetTermin;
        }
    }
}
