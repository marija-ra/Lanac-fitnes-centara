﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class ClanarinaDAO
    {
        public static List<ClanarinaDTO> sveClanarinePoClanuJMBBG(string JMBG)
        {
            String upit = "select * from clanarine_pogled where JMBG=?JMBG";
            List<ClanarinaDTO> lista = new List<ClanarinaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();

            comm.CommandText = upit;
            comm.Parameters.AddWithValue("JMBG", JMBG);

            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    ClanarinaDTO clanarina = new ClanarinaDTO();
                    clanarina.DatumPrijave = r.GetDateTime(0);
                    clanarina.DatumIsteka = r.GetDateTime(1);
                    clanarina.IdClanarine = r.GetInt32(2);

                    clanarina.TipClanarine = new TipClanarineDTO();
                    clanarina.TipClanarine.Naziv = r.GetString(3);
                    clanarina.TipClanarine.Cijena = r.GetInt32(4);

                    

                    clanarina.TipClanarine.TipTreninga = new TipTreningaDTO();
                    clanarina.TipClanarine.TipTreninga.Naziv = r.GetString(5);

                    clanarina.Clan = new ClanDTO();
                    clanarina.Clan.Jmbg = r.GetString(6);

                    clanarina.TipClanarine.TipTreninga.OpisTreninga = r.GetString(7);
                    lista.Add(clanarina);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }


        public static bool dodavanjeClanarine(string datumPrijave, string datumIsteka, int? IdGrupe, string JMBGClana, int IDTipaClanarine, int? IDFCentra, string JMBGRecepcionera)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodavanjeClanarine('" + datumPrijave + "','" + datumIsteka + "', ?IdGrupe,'" + JMBGClana + "','" + IDTipaClanarine + "',?IDFCentra,'"+ JMBGRecepcionera + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Parameters.AddWithValue("IDFCentra", IDFCentra);
                comm.Parameters.AddWithValue("IdGrupe", IdGrupe);

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
        
        public static ClanarinaDTO clanarinaPoID(int idClanarine)
        {
            String upit = "select * from clanarina where IDClanarine=?idClanarine";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("idClanarine", idClanarine);
            MySqlDataReader r = null;
            
            ClanarinaDTO clanarina = new ClanarinaDTO();
            clanarina.Clan = new ClanDTO();
            clanarina.TipClanarine = new TipClanarineDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    
                    
                    clanarina.DatumPrijave = r.GetDateTime(0);
                    clanarina.DatumIsteka = r.GetDateTime(1);
                    clanarina.Clan.Jmbg = r.GetString(2);
                    clanarina.TipClanarine.IdTipaClanarine = r.GetInt32(3);
                    clanarina.IdClanarine = r.GetInt32(4);

                    
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return clanarina;
        }


        public static bool brisanjeClanarine(int IDClanarine)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "delete from clanarina where IDClanarine =?IDClanarine";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Parameters.AddWithValue("IDClanarine", IDClanarine);

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
        
    }
}
