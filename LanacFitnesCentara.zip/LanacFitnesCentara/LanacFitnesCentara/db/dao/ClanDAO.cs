﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
     class ClanDAO
    {
        public static List<ClanDTO> sviClanovi()
        {
            String upit = "select * from clanovi_pogled";
            List<ClanDTO> lista = new List<ClanDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    ClanDTO novi = new ClanDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.ClanskiBroj = r.GetInt32(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<ClanDTO> sviClanoviUGrupi(int IDGrupe)
        {
            String upit = "select * from clanovi_u_grupama_pogled where IDGrupe=?IDGrupe";
            List<ClanDTO> lista = new List<ClanDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
            MySqlDataReader r = null;

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    ClanDTO novi = new ClanDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.ClanskiBroj = r.GetInt32(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }


            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;

        }

        public static List<ClanDTO> sviAktivniClanoviUGrupi(int IDGrupe)
        {
            String upit = "select * from clanovi_u_grupama_pogled where IDGrupe=?IDGrupe AND Aktivan=1";
            List<ClanDTO> lista = new List<ClanDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
            MySqlDataReader r = null;

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    ClanDTO novi = new ClanDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.ClanskiBroj = r.GetInt32(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }


            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;

        }
        
        public static ClanDTO clanPoJMBG(string jmbg)
        {
            String upit = "select * from clanovi_pogled where JMBG=?jmbg";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("jmbg", jmbg);
            MySqlDataReader r = null;
            ClanDTO novi = new ClanDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.ClanskiBroj = r.GetInt32(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeClana(ClanDTO c)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodajClana('" + c.Jmbg + "','" + c.Ime + "','" + c.Prezime + "','" + c.Adresa + "','" + c.Mjesto.IdMjesta + "','" + c.ClanskiBroj + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeClana(string jmbg, string ime, string prezime, string adresa, int idMjesta, int clanskiBroj, string stariJMBG )
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL urediClana('" + jmbg + "','" + ime + "','" + prezime + "','" + adresa + "','" + idMjesta + "','" + clanskiBroj + "','" + stariJMBG + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeClana(string jmbg)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "CALL brisanjaClana('" + jmbg + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        
    }
}
