﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TipGrupniTreningDAO
    {

        public static List<TipGrupniTreningDTO> sviTipoviGrupniTrening()
        {
            String upit = "select * from tipovi_grupni_trening_pogled";
            List<TipGrupniTreningDTO> lista = new List<TipGrupniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    TipGrupniTreningDTO novi = new TipGrupniTreningDTO();
                    TipTreningaDTO tip = new TipTreningaDTO();

                    novi.IdTipaTreninga = r.GetInt32(0);
                    novi.Naziv = r.GetString(1);
                    novi.TrajanjeUMinutama = r.GetInt32(2);
                    novi.Kapacitet = r.GetInt32(3);
                    tip.OpisTreninga = r.GetString(4);

                    novi.OpisTreninga = tip.OpisTreninga;
                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static TipGrupniTreningDTO tipGrupnogTreningaPoID(int idTipaTreninga)
        {
            String upit = "select * from tipovi_grupni_trening_pogled where idTipaTreninga=?idTipaTreninga";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("idTipaTreninga", idTipaTreninga);
            MySqlDataReader r = null;

            
            TipGrupniTreningDTO novi = new TipGrupniTreningDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.IdTipaTreninga = r.GetInt32(0);
                    novi.Naziv = r.GetString(1);
                    novi.TrajanjeUMinutama = r.GetInt32(2);
                    novi.Kapacitet = r.GetInt32(3);
                    novi.OpisTreninga = r.GetString(4);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeTipaGrupnogTreninga(TipGrupniTreningDTO tgt)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodajTipaGrupnogTreninga('" + tgt.Naziv + "'," + tgt.TrajanjeUMinutama + "," + tgt.Kapacitet + ",'" + tgt.OpisTreninga + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeTipaGrupnogTreninga(int idTipaTreninga, string naziv, int trajanjeUMinutama, int kapacitet, string opisTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL urediTipGrupnogTreninga(" + idTipaTreninga + ",'" + naziv + "'," + trajanjeUMinutama + "," + kapacitet + ",'" + opisTreninga +  "');";
            
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeTipaGrupnogTreninga(int idTipaTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "CALL brisanjaTipGrupnogTreninga(" + idTipaTreninga + ");";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
         
    }
}
