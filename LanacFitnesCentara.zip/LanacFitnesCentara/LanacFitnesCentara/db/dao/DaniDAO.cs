﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class DaniDAO
    {
        public static List<DaniDTO> sviDani()
        {
            String upit = "select * from dani";
            List<DaniDTO> lista = new List<DaniDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    DaniDTO dan = new DaniDTO();
                    dan.IdDana = r.GetInt32(0);
                    dan.Naziv = r.GetString(1);

                    lista.Add(dan);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

         public static DaniDTO danPoID(int IDDana)
        {
            

            String upit = "select * from dani where IDDana=?IDDana";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDDana", IDDana);
            MySqlDataReader r = null;

           DaniDTO dan = new DaniDTO();
                    

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {


                    dan.IdDana = r.GetInt32(0);
                    dan.Naziv = r.GetString(1);
                    

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return dan;
        }

    }
}
