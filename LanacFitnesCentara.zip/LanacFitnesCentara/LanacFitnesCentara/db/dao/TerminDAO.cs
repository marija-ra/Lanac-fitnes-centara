﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TerminDAO
    {
        public static bool dodavanjeTermina(TerminDTO t)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool zauzetTermin = false;

            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = new MySqlCommand();
                comm.Connection = conn;
                comm.CommandText = "dodavanjeTermina";
                comm.CommandType = CommandType.StoredProcedure;

                comm.Parameters.AddWithValue("@KoordinatorJMBG", t.Koordinator.Jmbg);
                comm.Parameters.AddWithValue("@vrijemeOd", t.Vrijeme);
                comm.Parameters.AddWithValue("@idSale", t.Sala.IdSale);
                comm.Parameters.AddWithValue("@idGrupe", t.Grupa.IdGrupe);
                comm.Parameters.AddWithValue("@idDana", t.DanUSedmici.IdDana);
                comm.Parameters.AddWithValue("@zauzetTermin", MySqlDbType.Bit);
                comm.Parameters["@zauzetTermin"].Direction = ParameterDirection.Output;


                comm.ExecuteNonQuery();

                zauzetTermin = Convert.ToBoolean(comm.Parameters["@zauzetTermin"].Value);
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return zauzetTermin;
        }

        public static bool dodavanjeTerminaZaIndividualni(TerminDTO t)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;
            
            String upit = "insert into termin values(null,'" + t.Koordinator.Jmbg + "','" + t.Vrijeme + "',null,null,'" + t.IndividualniTrening.IdIndividualnogTreninga + "','"+ t.DanUSedmici.IdDana + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }


        public static bool brisanjeTermina(int idTermina)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "delete from termin where IDTermina = " + idTermina + ";";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static List<TerminDTO> sviTerminiPoIDGrupe(int IDGrupe)
        {
            List<TerminDTO> lista = new List<TerminDTO>();

            String upit = "select * from termin where IDGrupe=?IDGrupe";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
            MySqlDataReader r = null;

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {


                    TerminDTO novi = new TerminDTO();
                    novi.Koordinator = new KoordinatorDTO();
                    novi.Koordinator.Mjesto = new MjestoDTO();
                    novi.Grupa = new GrupaDTO();
                    novi.Grupa.Tip = new TipGrupniTreningDTO();
                    novi.Grupa.Trener = new TrenerDTO();
                    novi.Grupa.Trener.Mjesto = new MjestoDTO();
                    novi.DanUSedmici = new DaniDTO();
                    novi.Sala = new SalaDTO();

                    novi.IndividualniTrening = new IndividualniTreningDTO();
                    novi.IndividualniTrening.Tip = new TipIndividualniTreningDTO();
                    novi.IndividualniTrening.Trener = new TrenerDTO();
                    novi.IndividualniTrening.Trener.Mjesto = new MjestoDTO();

                    novi.IdTermina = r.GetInt32(0);
                    novi.Koordinator.Jmbg = r.GetString(1);
                    novi.Vrijeme = r.GetString(2);

                    if (!r.IsDBNull(3))
                        novi.Sala.IdSale = r.GetInt32(3);
                    if (!r.IsDBNull(4))
                        novi.Grupa.IdGrupe = r.GetInt32(4);

                    if (!r.IsDBNull(5))
                        novi.IndividualniTrening.IdIndividualnogTreninga = r.GetInt32(5);

                    novi.DanUSedmici.IdDana = r.GetInt32(6);
                    novi.DanUSedmici = DaniDAO.danPoID(novi.DanUSedmici.IdDana);

                    lista.Add(novi);
                    
                }
            }

            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<TerminDTO> sviTerminiPoIDIndividualniTrening(int IDIndividualnogTreninga)
        {
            List<TerminDTO> lista = new List<TerminDTO>();

            String upit = "select * from termin where IDIndividualnogTreninga=?IDIndividualnogTreninga";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDIndividualnogTreninga", IDIndividualnogTreninga);
            MySqlDataReader r = null;

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {


                    TerminDTO novi = new TerminDTO();
                    novi.Koordinator = new KoordinatorDTO();
                    novi.Koordinator.Mjesto = new MjestoDTO();
                    novi.Grupa = new GrupaDTO();
                    novi.Grupa.Tip = new TipGrupniTreningDTO();
                    novi.Grupa.Trener = new TrenerDTO();
                    novi.Grupa.Trener.Mjesto = new MjestoDTO();
                    novi.DanUSedmici = new DaniDTO();
                    novi.Sala = new SalaDTO();

                    novi.IndividualniTrening = new IndividualniTreningDTO();
                    novi.IndividualniTrening.Tip = new TipIndividualniTreningDTO();
                    novi.IndividualniTrening.Trener = new TrenerDTO();
                    novi.IndividualniTrening.Trener.Mjesto = new MjestoDTO();

                    novi.IdTermina = r.GetInt32(0);
                    novi.Koordinator.Jmbg = r.GetString(1);
                    novi.Vrijeme = r.GetString(2);

                    if (!r.IsDBNull(3))
                        novi.Sala.IdSale = r.GetInt32(3);
                    if (!r.IsDBNull(4))
                        novi.Grupa.IdGrupe = r.GetInt32(4);

                    if (!r.IsDBNull(5))
                        novi.IndividualniTrening.IdIndividualnogTreninga = r.GetInt32(5);

                    novi.DanUSedmici.IdDana = r.GetInt32(6);
                    novi.DanUSedmici = DaniDAO.danPoID(novi.DanUSedmici.IdDana);

                    lista.Add(novi);

                }
            }

            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static TerminDTO terminPoID(int IDTermina)
        {
            

            String upit = "select * from termin where IDTermina=?IDTermina";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTermina", IDTermina);
            MySqlDataReader r = null;

            TerminDTO novi = new TerminDTO();
            novi.DanUSedmici = new DaniDTO();
            novi.Koordinator = new KoordinatorDTO();
            novi.Koordinator.Mjesto = new MjestoDTO();
            novi.Grupa = new GrupaDTO();
            novi.Grupa.Tip = new TipGrupniTreningDTO();
            novi.Grupa.Trener = new TrenerDTO();
            novi.Grupa.Trener.Mjesto = new MjestoDTO();
            novi.Sala = new SalaDTO();

            novi.IndividualniTrening = new IndividualniTreningDTO();
            novi.IndividualniTrening.Tip = new TipIndividualniTreningDTO();
            novi.IndividualniTrening.Trener = new TrenerDTO();
            novi.IndividualniTrening.Trener.Mjesto = new MjestoDTO();

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {


                    novi.IdTermina = r.GetInt32(0);
                    novi.Koordinator.Jmbg = r.GetString(1);
                    novi.Vrijeme = r.GetString(2);
                    if (!r.IsDBNull(3))
                        novi.Sala.IdSale = r.GetInt32(3);
                    if (!r.IsDBNull(4))
                        novi.Grupa.IdGrupe = r.GetInt32(4);

                    if (!r.IsDBNull(5))
                        novi.IndividualniTrening.IdIndividualnogTreninga = r.GetInt32(5);

                    novi.DanUSedmici.IdDana = r.GetInt32(6);
                    novi.DanUSedmici = DaniDAO.danPoID(novi.DanUSedmici.IdDana);

                    

                }
            }

            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }
    }
}
