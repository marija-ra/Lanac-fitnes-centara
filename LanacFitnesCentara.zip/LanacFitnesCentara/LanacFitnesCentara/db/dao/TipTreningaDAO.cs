﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TipTreningaDAO
    {

        public static TipTreningaDTO tipTreningaPoID(int idTipaTreninga)
        {
            String upit = "select * from tip_treninga where idTipaTreninga=?idTipaTreninga";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("idTipaTreninga", idTipaTreninga);
            MySqlDataReader r = null;


            TipTreningaDTO novi = new TipTreningaDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.IdTipaTreninga = r.GetInt32(0);
                    novi.Naziv = r.GetString(1);
                    novi.TrajanjeUMinutama = r.GetInt32(2);
                    novi.OpisTreninga = r.GetString(3);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }
    }
}
