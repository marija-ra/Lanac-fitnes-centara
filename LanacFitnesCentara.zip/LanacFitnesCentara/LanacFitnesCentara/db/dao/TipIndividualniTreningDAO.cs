﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TipIndividualniTreningDAO
    {

        public static List<TipIndividualniTreningDTO> sviTipoviIndividualniTrening()
        {
            String upit = "select * from tipovi_individualni_trening_pogled";
            List<TipIndividualniTreningDTO> lista = new List<TipIndividualniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    TipIndividualniTreningDTO novi = new TipIndividualniTreningDTO();
                    TipTreningaDTO tip = new TipTreningaDTO();

                    novi.IdTipaTreninga = r.GetInt32(0);
                    novi.Naziv = r.GetString(1);
                    novi.TrajanjeUMinutama = r.GetInt32(2);                
                    tip.OpisTreninga = r.GetString(3);

                    novi.OpisTreninga = tip.OpisTreninga;
                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static TipIndividualniTreningDTO tipIndividualnogTreningaPoID(int idTipaTreninga)
        {
            String upit = "select * from tipovi_individualni_trening_pogled where idTipaTreninga=?idTipaTreninga";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("idTipaTreninga", idTipaTreninga);
            MySqlDataReader r = null;


            TipIndividualniTreningDTO novi = new TipIndividualniTreningDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    novi.IdTipaTreninga = r.GetInt32(0);
                    novi.Naziv = r.GetString(1);
                    novi.TrajanjeUMinutama = r.GetInt32(2);
                    novi.OpisTreninga = r.GetString(3);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeTipaIndividualnogTreninga(TipIndividualniTreningDTO tit)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL dodajTipaIndividualnogTreninga('" + tit.Naziv + "'," + tit.TrajanjeUMinutama + ",'" + tit.OpisTreninga + "');";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeTipaIndividualnogTreninga(int idTipaTreninga, string naziv, int trajanjeUMinutama, string opisTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "update tip_treninga set naziv ='" + naziv + "', trajanjeUMinutama =" + trajanjeUMinutama + ", opisTreninga ='" + opisTreninga + "' where idTipaTreninga =" + idTipaTreninga + ");";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeTipaIndividualnogTreninga(int idTipaTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "CALL brisanjaIndividualnogTreninga(" + idTipaTreninga + ");";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
        
    }
}
