﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class FitnesCentarDAO
    {

        public static List<FitnesCentarDTO> sviFitnesCentri()
        {
            String upit = "select * from fitnes_centri_pogled";
            List<FitnesCentarDTO> lista = new List<FitnesCentarDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    FitnesCentarDTO novi = new FitnesCentarDTO();
                    MjestoDTO mjesto = new MjestoDTO();
                    ZaposlenikDTO direktor = new ZaposlenikDTO();

                    novi.IdFCentra = r.GetInt32(0);
                    novi.Email = r.GetString(1);
                    novi.RadnoVrijeme = r.GetString(2);
                    mjesto.IdMjesta = r.GetInt32(3);
                    mjesto.Grad = r.GetString(4);
                    mjesto.Regija = r.GetString(5);
                    mjesto.Naziv = r.GetString(6);
                    novi.Mjesto = mjesto;

                    direktor.Jmbg = r.GetString(7);
                    direktor.Ime = r.GetString(8);
                    direktor.Prezime = r.GetString(9);
                    direktor.Adresa = r.GetString(10);
                    direktor.StrucnaSprema = r.GetString(11);
                    novi.Direktor = direktor;

                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static FitnesCentarDTO fitnesCentarPoID(int IdFCentra)
        {
            String upit = "select * from fitnes_centri_pogled where IdFCentra=?IdFCentra";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IdFCentra", IdFCentra);
            MySqlDataReader r = null;
            FitnesCentarDTO novi = new FitnesCentarDTO();
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    
                    MjestoDTO mjesto = new MjestoDTO();
                    ZaposlenikDTO direktor = new ZaposlenikDTO();

                    novi.IdFCentra = r.GetInt32(0);
                    novi.Email = r.GetString(1);
                    novi.RadnoVrijeme = r.GetString(2);
                    mjesto.IdMjesta = r.GetInt32(3);
                    mjesto.Grad = r.GetString(4);
                    mjesto.Regija = r.GetString(5);
                    mjesto.Naziv = r.GetString(6);
                    novi.Mjesto = mjesto;

                    direktor.Jmbg = r.GetString(7);
                    direktor.Ime = r.GetString(8);
                    direktor.Prezime = r.GetString(9);
                    direktor.Adresa = r.GetString(10);
                    direktor.StrucnaSprema = r.GetString(11);
                    novi.Direktor = direktor;

                   
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }

        public static bool dodavanjeFitnesCentra(FitnesCentarDTO f)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "insert into fitnes_centar values(null, @email, @radnoVrijeme, @idMjesta, @jmbgDirektora )";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Prepare();
                comm.Parameters.AddWithValue("@email", f.Email);
                comm.Parameters.AddWithValue("@radnoVrijeme", f.RadnoVrijeme);
                comm.Parameters.AddWithValue("@idMjesta", f.Mjesto.IdMjesta);
                comm.Parameters.AddWithValue("@jmbgDirektora", f.Direktor.Jmbg);


                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeFitnesCentra(int idFCentra, string email, DateTime? radnoVrijeme, int idMjesta,  string jmbgDirektora)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "update fitnes_centar set email= @email, radnoVrijeme= @radnoVrijeme, idMjesta = @idMjesta, jmbgDirektora = @jmbgDirektora";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                comm.Prepare();
                comm.Parameters.AddWithValue("@email", email);
                comm.Parameters.AddWithValue("@radnoVrijeme", radnoVrijeme);
                comm.Parameters.AddWithValue("@idMjesta", idMjesta);
                comm.Parameters.AddWithValue("@jmbgDirektora", jmbgDirektora);

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeFitnesCentra(int idFCentra)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "delete from fitnes_centar where idFCentra = " + idFCentra + ");";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
    }
}
