﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class ZaposlenikDAO
    {
        public static List<ZaposlenikDTO> sviZaposleni()
        {
            String upit = "select * from zaposlenik_pogled";
            List<ZaposlenikDTO> lista = new List<ZaposlenikDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    ZaposlenikDTO novi = new ZaposlenikDTO();
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    lista.Add(novi);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }


        public static ZaposlenikDTO zaposlenikPoJMBG(string jmbg)
        {
            String upit = "select * from zaposlenik_pogled where JMBG=?jmbg";
            List<ZaposlenikDTO> lista = new List<ZaposlenikDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;

            comm.Parameters.AddWithValue("jmbg", jmbg);

            ZaposlenikDTO novi = new ZaposlenikDTO();
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    
                    novi.Jmbg = r.GetString(0);
                    novi.Ime = r.GetString(1);
                    novi.Prezime = r.GetString(2);
                    novi.Adresa = r.GetString(3);
                    novi.StrucnaSprema = r.GetString(4);

                    MjestoDTO mjesto = new MjestoDTO();
                    mjesto.IdMjesta = r.GetInt32(5);
                    mjesto.Grad = r.GetString(6);
                    mjesto.Regija = r.GetString(7);
                    mjesto.Naziv = r.GetString(8);
                    novi.Mjesto = mjesto;

                    
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return novi;
        }
    }
}
