﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class GrupaDAO
    {

        public static List<GrupaDTO> sveGrupe()
        {
            String upit = "select * from tip_grupa_trener_pogled";
            List<GrupaDTO> lista = new List<GrupaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();
                                      
                    
                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);

                    
                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);

                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);



                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<GrupaDTO> sveAktivneGrupe()
        {
            String upit = "select * from aktivne_grupe";
            List<GrupaDTO> lista = new List<GrupaDTO>();

            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();


                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);

                   
                        grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);



                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<GrupaDTO> sveAktivneGrupePoIDFitnesCentar(int IDFitnesCentra)
        {
            String upit = "select * from aktivne_grupe where IDFitnesCentra=?IDFitnesCentra";
            List<GrupaDTO> lista = new List<GrupaDTO>();

            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDFitnesCentra", IDFitnesCentra);
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();


                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);


                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);



                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<GrupaDTO> sveGrupePoFitnesCentarID(int IDFitnesCentra)
        {
            String upit = "select * from tip_grupa_trener_pogled where IDFitnesCentra=?IDFitnesCentra";
            List<GrupaDTO> lista = new List<GrupaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDFitnesCentra", IDFitnesCentra);
            MySqlDataReader r = null;


            

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();

                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);
                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);

                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static GrupaDTO grupaPoID(int IDGrupe)
        {
            String upit = "select * from tip_grupa_trener_pogled where IDGrupe=?IDGrupe";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
            MySqlDataReader r = null;


            GrupaDTO grupa = new GrupaDTO();
            grupa.Tip = new TipGrupniTreningDTO();
            grupa.FitnesCentar = new FitnesCentarDTO();
            grupa.Trener = new TrenerDTO();
            grupa.Trener.Mjesto = new MjestoDTO();

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);
                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);
                    
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return grupa;
        }

        public static GrupaDTO aktivnaGrupaPoID(int IDGrupe)
        {
            String upit = "select * from aktivne_grupe where IDGrupe=?IDGrupe";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
            MySqlDataReader r = null;


            GrupaDTO grupa = new GrupaDTO();
            grupa.Tip = new TipGrupniTreningDTO();
            grupa.FitnesCentar = new FitnesCentarDTO();
            grupa.Trener = new TrenerDTO();
            grupa.Trener.Mjesto = new MjestoDTO();

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);
                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return grupa;
        }

        public static List<GrupaDTO> sveGrupeTipa(int IDTipaTreninga)
        {
            String upit = "select * from tip_grupa_trener_pogled where IDTipaTreninga=?IDTipaTreninga";
            List<GrupaDTO> lista = new List<GrupaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTipaTreninga", IDTipaTreninga);
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();


                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);

                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);

                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<GrupaDTO> sveSlobodneGrupeTipa(int IDTipaTreninga)
        {
            String upit = "select * from tip_grupa_trener_pogled where IDTipaTreninga=?IDTipaTreninga AND Kapacitet>TrenutniBrojClanova";
            List<GrupaDTO> lista = new List<GrupaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTipaTreninga", IDTipaTreninga);
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    GrupaDTO grupa = new GrupaDTO();
                    grupa.Tip = new TipGrupniTreningDTO();
                    grupa.FitnesCentar = new FitnesCentarDTO();
                    grupa.Trener = new TrenerDTO();
                    grupa.Trener.Mjesto = new MjestoDTO();


                    grupa.Tip.IdTipaTreninga = r.GetInt32(0);
                    grupa.IdGrupe = r.GetInt32(1);
                    grupa.TrenutniBrojClanova = r.GetInt32(2);
                    grupa.FitnesCentar.IdFCentra = r.GetInt32(3);
                    grupa.Tip.Kapacitet = r.GetInt32(4);
                    grupa.Tip.OpisTreninga = r.GetString(5);


                    grupa.Trener.Jmbg = r.GetString(6);
                    grupa.Trener.Ime = r.GetString(7);
                    grupa.Trener.Prezime = r.GetString(8);
                    grupa.Trener.Adresa = r.GetString(9);
                    grupa.Trener.StrucnaSprema = r.GetString(10);


                    grupa.Trener.Mjesto.IdMjesta = r.GetInt32(11);
                    grupa.Trener.Mjesto.Grad = r.GetString(12);
                    grupa.Trener.Mjesto.Regija = r.GetString(13);
                    grupa.Trener.Mjesto.Naziv = r.GetString(14);

                    grupa.Tip.Naziv = r.GetString(15);
                    grupa.Tip.TrajanjeUMinutama = r.GetInt32(16);

                    grupa.DatumKreiranja = r.GetDateTime(17);
                    if (!r.IsDBNull(18))
                        grupa.DatumDeaktiviranja = r.GetDateTime(18);


                    lista.Add(grupa);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static bool dodavanjeGrupe(GrupaDTO g)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;



            String upit = "insert into grupa values(" + g.Tip.IdTipaTreninga + "," + g.IdGrupe + "," + g.TrenutniBrojClanova + ",'" + g.Trener.Jmbg + "'," + g.FitnesCentar.IdFCentra + ",'" + g.DatumKreiranja.ToString("yyyy-MM-hh") + "', null);";
            
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool uredjivanjeGrupe(int IDTipaTreninga, int IDGrupe, string JMBGTrenera, int IDFitnesCentra)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "CALL urediGrupu(" + IDTipaTreninga + "," + IDGrupe + ",'" + JMBGTrenera + "'," + IDFitnesCentra + ");";
            
            try
            {
                conn = ConnectionPool.checkOutConnection();
                

                comm = conn.CreateCommand();
                
                comm.CommandText = upit;
                
                

                rezultat = comm.ExecuteNonQuery() == 1;

                
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeGrupe(int IDGrupe)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "delete from grupa where IDGrupe=?IDGrupe;";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool obrisiClanaIzGrupe(string JMBGClana, int IDGrupe)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "update grupa_clan set Aktivan=0 where IDGrupe=?IDGrupe AND JMBGClana=?JMBGClana;";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Parameters.AddWithValue("IDGrupe", IDGrupe);
                comm.Parameters.AddWithValue("JMBGClana", JMBGClana);
                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }
    }
}
