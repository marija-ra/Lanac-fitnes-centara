﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class SalaDAO
    {
        public static List<SalaDTO> sveSalePoIDFitnesCentra(int IDFCentra, int kapacitetTipGrupnogTreninga)
        {
            String upit = "select * from sala where IDFCentra=?IDFCentra AND Kapacitet>=?kapacitetTipGrupnogTreninga";
            List<SalaDTO> lista = new List<SalaDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDFCentra", IDFCentra);
            comm.Parameters.AddWithValue("kapacitetTipGrupnogTreninga", kapacitetTipGrupnogTreninga);
            MySqlDataReader r = null;


            

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    SalaDTO sala = new SalaDTO();
                    sala.FitnesCentar = new FitnesCentarDTO();

                    sala.IdSale = r.GetInt32(0);
                    sala.Kapacitet = r.GetInt32(1);
                    sala.FitnesCentar.IdFCentra = r.GetInt32(2);
                    sala.FitnesCentar = FitnesCentarDAO.fitnesCentarPoID(sala.FitnesCentar.IdFCentra);

                    lista.Add(sala);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<RasporedSaleDTO> rasporedSalePoID(int IDSale)
        {
            String upit = "select * from raspored_sala_pogled where IDSale=?IDSale";
            List<RasporedSaleDTO> lista = new List<RasporedSaleDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDSale", IDSale);
            
            MySqlDataReader r = null;




            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    RasporedSaleDTO sala = new RasporedSaleDTO();
                    
                    sala.IdSale = r.GetInt32(0);
                    sala.DanUSedmici = r.GetString(1);
                    sala.VrijemeOd = r.GetString(2);
                    sala.VrijemeDo = r.GetString(3);
                    sala.Grupa = r.GetString(4);

                    lista.Add(sala);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }
    }
}
