﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class IndividualniTreningDAO
    {
        public static List<IndividualniTreningDTO> sviIndividualniTreninzi()
        {
            String upit = "select * from tip_individualni_trening_trener_pogled";
            List<IndividualniTreningDTO> lista = new List<IndividualniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
                    individualniTrening.Tip = new TipIndividualniTreningDTO();
                    individualniTrening.Clan = new ClanDTO();
                    individualniTrening.Trener = new TrenerDTO();
                    individualniTrening.Trener.Mjesto = new MjestoDTO();


                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);

                    if (!r.IsDBNull(115))
                    individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);



                    lista.Add(individualniTrening);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<IndividualniTreningDTO> sviAktivniIndividualniTreninzi()
        {
            String upit = "select * from aktivni_individualni_treninzi";
            List<IndividualniTreningDTO> lista = new List<IndividualniTreningDTO>();

            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
                    individualniTrening.Tip = new TipIndividualniTreningDTO();
                    individualniTrening.Clan = new ClanDTO();
                    individualniTrening.Trener = new TrenerDTO();
                    individualniTrening.Trener.Mjesto = new MjestoDTO();


                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);

                    if (!r.IsDBNull(15))
                        individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);





                    lista.Add(individualniTrening);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<IndividualniTreningDTO> sviIdividualniTreningPoJMBGClana(string JMBGClana)
        {
            String upit = "select * from tip_individualni_trening_trener_pogled where JMBGClana=?JMBGClana";
            List<IndividualniTreningDTO> lista = new List<IndividualniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("JMBGClana", JMBGClana);
            MySqlDataReader r = null;


            

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {

                    IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
                    individualniTrening.Tip = new TipIndividualniTreningDTO();
                    individualniTrening.Clan = new ClanDTO();
                    individualniTrening.Trener = new TrenerDTO();
                    individualniTrening.Trener.Mjesto = new MjestoDTO();

                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);

                    if (!r.IsDBNull(15))
                    individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);

                    lista.Add(individualniTrening);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<IndividualniTreningDTO> sviAktivniIndividualniTreningPoJMBGClana(string JMBGClana)
        {
            String upit = "select * from aktivni_individualni_treninzi where JMBGClana=?JMBGClana";
            List<IndividualniTreningDTO> lista = new List<IndividualniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("JMBGClana", JMBGClana);
            MySqlDataReader r = null;




            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {

                    IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
                    individualniTrening.Tip = new TipIndividualniTreningDTO();
                    individualniTrening.Clan = new ClanDTO();
                    individualniTrening.Trener = new TrenerDTO();
                    individualniTrening.Trener.Mjesto = new MjestoDTO();

                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);

                    if (!r.IsDBNull(15))
                    individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);

                    lista.Add(individualniTrening);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<IndividualniTreningDTO> sviIndividualniTreninziTipa(int IDTipaTreninga)
        {
            String upit = "select * from tip_individualni_trening_trener_pogled where IDTipaTreninga=?IDTipaTreninga";
            List<IndividualniTreningDTO> lista = new List<IndividualniTreningDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTipaTreninga", IDTipaTreninga);
            MySqlDataReader r = null;




            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {

                    IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
                    individualniTrening.Tip = new TipIndividualniTreningDTO();
                    individualniTrening.Clan = new ClanDTO();
                    individualniTrening.Trener = new TrenerDTO();
                    individualniTrening.Trener.Mjesto = new MjestoDTO();

                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);

                    if (!r.IsDBNull(15))
                        individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);

                    lista.Add(individualniTrening);

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static IndividualniTreningDTO individualniTreningPoID(int IDIndividualnogTreninga)
        {
            String upit = "select * from tip_individualni_trening_trener_pogled where IDIndividualnogTreninga=?IDIndividualnogTreninga";
           
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDIndividualnogTreninga", IDIndividualnogTreninga);
            MySqlDataReader r = null;



            IndividualniTreningDTO individualniTrening = new IndividualniTreningDTO();
            individualniTrening.Tip = new TipIndividualniTreningDTO();
            individualniTrening.Clan = new ClanDTO();
            individualniTrening.Trener = new TrenerDTO();
            individualniTrening.Trener.Mjesto = new MjestoDTO();

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {


                    individualniTrening.Tip.IdTipaTreninga = r.GetInt32(0);
                    individualniTrening.IdIndividualnogTreninga = r.GetInt32(1);
                    individualniTrening.Clan.Jmbg = r.GetString(2);
                    individualniTrening.Tip.OpisTreninga = r.GetString(3);


                    individualniTrening.Trener.Jmbg = r.GetString(4);
                    individualniTrening.Trener.Ime = r.GetString(5);
                    individualniTrening.Trener.Prezime = r.GetString(6);
                    individualniTrening.Trener.Adresa = r.GetString(7);
                    individualniTrening.Trener.StrucnaSprema = r.GetString(8);


                    individualniTrening.Trener.Mjesto.IdMjesta = r.GetInt32(9);
                    individualniTrening.Trener.Mjesto.Grad = r.GetString(10);
                    individualniTrening.Trener.Mjesto.Regija = r.GetString(11);
                    individualniTrening.Trener.Mjesto.Naziv = r.GetString(12);

                    individualniTrening.Tip.Naziv = r.GetString(13);
                    individualniTrening.Tip.TrajanjeUMinutama = r.GetInt32(14);


                    if (!r.IsDBNull(15))
                        individualniTrening.DatumKreiranja = r.GetDateTime(15);
                    if (!r.IsDBNull(16))
                        individualniTrening.DatumDeaktiviranja = r.GetDateTime(16);

                    

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return individualniTrening;
        }

        public static bool dodavanjeIndividualnogTreninga(IndividualniTreningDTO i)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;



            String upit = "insert into individualni_trening values(" + i.Tip.IdTipaTreninga + "," + i.IdIndividualnogTreninga + ",'" + i.Trener.Jmbg + "','" + i.Clan.Jmbg + "','" + i.DatumKreiranja.ToString("yyyy-MM-hh") + "', null);";

            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }


        public static bool uredjivanjeIndividualnogTreninga(int IDTipaTreninga, string JMBGClana, string JMBGTrenera, int IDIndividualnogTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "update individualni_trening set IDTipaTreninga=?IDTipaTreninga, JMBGTrenera=?JMBGTrenera, JMBGClana=?JMBGClana  where IDIndividualnogTreninga=?IDIndividualnogTreninga";
            try
            {
                conn = ConnectionPool.checkOutConnection();


                comm = conn.CreateCommand();
                comm.Parameters.AddWithValue("IDTipaTreninga", IDTipaTreninga);
                comm.Parameters.AddWithValue("JMBGClana", JMBGClana);
                comm.Parameters.AddWithValue("JMBGTrenera", JMBGTrenera);
                comm.Parameters.AddWithValue("IDIndividualnogTreninga", IDIndividualnogTreninga);
                comm.CommandText = upit;



                rezultat = comm.ExecuteNonQuery() == 1;


            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        public static bool brisanjeIndividualnogTreninga(int IDIndividualnogTreninga)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;


            String upit = "delete from individualni_trening where IDIndividualnogTreninga=?IDIndividualnogTreninga;";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;
                comm.Parameters.AddWithValue("IDIndividualnogTreninga", IDIndividualnogTreninga);
                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        
    }
}
