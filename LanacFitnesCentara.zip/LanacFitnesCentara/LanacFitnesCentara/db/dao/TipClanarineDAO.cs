﻿using LanacFitnesCentara.db.dto;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanacFitnesCentara.db.dao
{
    class TipClanarineDAO
    {
        public static List<TipClanarineDTO> sviTipoviClanarina()
        {
            String upit = "select * from tip_clanarine";
            List<TipClanarineDTO> lista = new List<TipClanarineDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            MySqlDataReader r = null;

            
            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    TipClanarineDTO tip = new TipClanarineDTO();
                    tip.TipTreninga = new TipTreningaDTO();
                    
                    tip.IdTipaClanarine = r.GetInt32(0);
                    tip.Naziv = r.GetString(1);
                    tip.Cijena = r.GetInt32(2);
                    
                    if (!r.IsDBNull(3))
                        tip.TipTreninga.IdTipaTreninga = r.GetInt32(3);
                     

                    lista.Add(tip);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static List<TipClanarineDTO> sviTipoviClanarinaPoIDTipuTreninga(int IDTipaTreninga)
        {
            String upit = "select * from tip_clanarine where IDTipaTreninga=?IDTipaTreninga";
            List<TipClanarineDTO> lista = new List<TipClanarineDTO>();
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTipaTreninga", IDTipaTreninga);
            MySqlDataReader r = null;


            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    TipClanarineDTO tip = new TipClanarineDTO();
                    tip.TipTreninga = new TipTreningaDTO();


                    tip.IdTipaClanarine = r.GetInt32(0);
                    tip.Naziv = r.GetString(1);
                    tip.Cijena = r.GetInt32(2);
                    //? sta kad je null
                    if (!r.IsDBNull(3))
                        tip.TipTreninga.IdTipaTreninga = r.GetInt32(3);


                    lista.Add(tip);
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return lista;
        }

        public static bool dodavanjeTipaClanarine(TipClanarineDTO tc)
        {
            MySqlConnection conn = null;
            MySqlCommand comm = null;
            bool rezultat = false;

            String upit = "insert into tip_clanarine values(" + tc.IdTipaClanarine + ",'" + tc.Naziv + "'," + tc.Cijena + ", "+tc.TipTreninga.IdTipaTreninga +");";
            try
            {
                conn = ConnectionPool.checkOutConnection();
                comm = conn.CreateCommand();
                comm.CommandText = upit;

                rezultat = comm.ExecuteNonQuery() == 1;
            }
            catch (MySqlException e)
            {
                MessageBox.Show("Error " + e.Number + " has occured: " + e.Message, "Error ",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                ConnectionPool.checkInConnection(conn);
                conn.Close();
            }
            return rezultat;
        }

        
        public static TipClanarineDTO tipClanarinePoID(int IDTipaClanarine)
        {
            String upit = "select * from tip_clanarine where IDTipaClanarine=?IDTipaClanarine";
            MySqlConnection conn = ConnectionPool.checkOutConnection();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = upit;
            comm.Parameters.AddWithValue("IDTipaClanarine", IDTipaClanarine);
            MySqlDataReader r = null;


            TipClanarineDTO tip = new TipClanarineDTO();
            tip.TipTreninga = new TipTreningaDTO();

            try
            {
                r = comm.ExecuteReader();
                while (r.Read())
                {
                    
                    tip.IdTipaClanarine = r.GetInt32(0);
                    tip.Naziv = r.GetString(1);
                    tip.Cijena = r.GetInt32(2);
                    
                    if (!r.IsDBNull(3))
                        tip.TipTreninga.IdTipaTreninga = r.GetInt32(3);
                     
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (r != null) r.Close();
                ConnectionPool.checkInConnection(conn);
            }

            return tip;
        }
    }
}
