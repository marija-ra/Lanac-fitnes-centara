﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class TipTreningaDTO
    {
        private int idTipaTreninga;
        private string naziv;
        private int trajanjeUMinutama;
        private string opisTreninga;


        public int IdTipaTreninga
        {
            get { return idTipaTreninga; }
            set { idTipaTreninga = value; }
        }


        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }


        public int TrajanjeUMinutama
        {
            get { return trajanjeUMinutama; }
            set { trajanjeUMinutama = value; }
        }

        public string OpisTreninga
        {
            get { return opisTreninga; }
            set { opisTreninga = value; }
        }

    }
}
