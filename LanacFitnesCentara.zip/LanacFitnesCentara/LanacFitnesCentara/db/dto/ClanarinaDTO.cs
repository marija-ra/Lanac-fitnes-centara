﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class ClanarinaDTO
    {
        private int idClanarine;
        private ClanDTO clan;
        private DateTime? datumPrijave;
        private DateTime? datumIsteka;
        private TipClanarineDTO tipClanarine;

        public int IdClanarine
        {
            get { return idClanarine; }
            set { idClanarine = value; }
        }
        

        internal ClanDTO Clan
        {
            get { return clan; }
            set { clan = value; }
        }
        

        public DateTime? DatumPrijave
        {
            get { return datumPrijave; }
            set { datumPrijave = value; }
        }
        

        public DateTime? DatumIsteka
        {
            get { return datumIsteka; }
            set { datumIsteka = value; }
        }
        

        internal TipClanarineDTO TipClanarine
        {
            get { return tipClanarine; }
            set { tipClanarine = value; }
        }

    }
}
