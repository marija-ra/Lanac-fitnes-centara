﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class GrupaDTO
    {
        private int idGrupe;
        private TipGrupniTreningDTO tip;
        private int trenutniBrojClanova;
        private TrenerDTO trener;
        private FitnesCentarDTO fitnesCentar;
        private DateTime datumKreiranja;
        private DateTime? datumDeaktiviranja;


        public DateTime DatumKreiranja
        {
            get { return datumKreiranja; }
            set { datumKreiranja = value; }
        }        

        public DateTime? DatumDeaktiviranja
        {
            get { return datumDeaktiviranja; }
            set { datumDeaktiviranja = value; }
        }

        internal FitnesCentarDTO FitnesCentar
        {
            get { return fitnesCentar; }
            set { fitnesCentar = value; }
        }

        public int IdGrupe
        {
            get { return idGrupe; }
            set { idGrupe = value; }
        }


        public TipGrupniTreningDTO Tip
        {
            get { return tip; }
            set { tip = value; }
        }
        

        public int TrenutniBrojClanova
        {
            get { return trenutniBrojClanova; }
            set { trenutniBrojClanova = value; }
        }


        public TrenerDTO Trener
        {
            get { return trener; }
            set { trener = value; }
        }

    }
}
