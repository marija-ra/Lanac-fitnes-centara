﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class DaniDTO

    {
        private int idDana;
        private string naziv;

        public DaniDTO()
        {
        }
        
        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }

        public int IdDana
        {
            get { return idDana; }
            set { idDana = value; }
        }

        

        


    }
}
