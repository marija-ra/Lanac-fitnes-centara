﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class TipClanarineDTO
    {
        private int idTipaClanarine;
        private string naziv;
        private double cijena;
        private TipTreningaDTO tipTreninga;

        public int IdTipaClanarine
        {
            get { return idTipaClanarine; }
            set { idTipaClanarine = value; }
        }
        

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }
        

        public double Cijena
        {
            get { return cijena; }
            set { cijena = value; }
        }
        

        internal TipTreningaDTO TipTreninga
        {
            get { return tipTreninga; }
            set { tipTreninga = value; }
        }



    }
}
