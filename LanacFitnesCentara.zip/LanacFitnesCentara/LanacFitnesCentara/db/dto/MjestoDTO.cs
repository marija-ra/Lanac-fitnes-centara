﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class MjestoDTO
    {
        public int idMjesta;
        public string grad;
        public string regija;
        public string naziv;

        public string Grad
        {
            get { return grad; }
            set { grad = value; }
        }


        public string Regija
        {
            get { return regija; }
            set { regija = value; }
        }


        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }

        public int IdMjesta
        {
            get { return idMjesta; }
            set { idMjesta = value; }
        }
    }
}
