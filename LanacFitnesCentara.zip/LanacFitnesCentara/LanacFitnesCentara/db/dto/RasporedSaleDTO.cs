﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class RasporedSaleDTO

    {
        private int idSale;
        private string danUSedmici;
        private string vrijemeOd;
        private string vrijemeDo;
        private string grupa;

        public RasporedSaleDTO()
        {
        }

        public int IdSale
        {
            get { return idSale; }
            set { idSale = value; }
        }
        

        public string DanUSedmici
        {
            get { return danUSedmici; }
            set { danUSedmici = value; }
        }
        

        public string VrijemeOd
        {
            get { return vrijemeOd; }
            set { vrijemeOd = value; }
        }
       
        public string VrijemeDo
        {
            get { return vrijemeDo; }
            set { vrijemeDo = value; }
        }
        

        public string Grupa
        {
            get { return grupa; }
            set { grupa = value; }
        }

       
        
       

        

        


    }
}
