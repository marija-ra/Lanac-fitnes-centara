﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class ClanDTO : OsobaDTO
    {
        public int clanskiBroj;

        public ClanDTO()
        {
        }

        public int ClanskiBroj
        {
            get { return clanskiBroj; }
            set { clanskiBroj = value; }
        }

    }
}
