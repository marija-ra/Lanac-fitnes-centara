﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class OsobaDTO
    {
        public string jmbg;
        public string ime;
        public string prezime;
        public string adresa;
        public MjestoDTO mjesto;
        

        public string Jmbg
        {
            get { return jmbg; }
            set { jmbg = value; }
        }

        public string Ime
        {
            get { return ime; }
            set { ime = value; }
        }

        public string Prezime
        {
            get { return prezime; }
            set { prezime = value; }
        }

        
        public string Adresa
        {
            get { return adresa; }
            set { adresa = value; }
        }

        public MjestoDTO Mjesto
        {
            get { return mjesto; }
            set { mjesto = value; }
        }


    }
}
