﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class FitnesCentarDTO
    {
        private int idFCentra;
        private string email;
        private string radnoVrijeme;
        private MjestoDTO mjesto;
        private ZaposlenikDTO direktor;
        

        public int IdFCentra
        {
            get { return idFCentra; }
            set { idFCentra = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        public string RadnoVrijeme
        {
            get { return radnoVrijeme; }
            set { radnoVrijeme = value; }
        }

        public MjestoDTO Mjesto
        {
            get { return mjesto; }
            set { mjesto = value; }
        }

        public ZaposlenikDTO Direktor
        {
            get { return direktor; }
            set { direktor = value; }
        }

        
       




    }
}
