﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class SalaDTO
    {
        private int idSale;
        private int kapacitet;
        private FitnesCentarDTO fitnesCentar;

        public int IdSale
        {
            get { return idSale; }
            set { idSale = value; }
        }
        

        internal FitnesCentarDTO FitnesCentar
        {
            get { return fitnesCentar; }
            set { fitnesCentar = value; }
        }
        

        public int Kapacitet
        {
            get { return kapacitet; }
            set { kapacitet = value; }
        }



    }
}
