﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    public class IndividualniTreningDTO
    {
        private int idIndividualnogTreninga;

        
        private TipIndividualniTreningDTO tip;
        private TrenerDTO trener;
        private ClanDTO clan;
        private DateTime datumKreiranja;
        private DateTime? datumDeaktiviranja;

        
        public DateTime DatumKreiranja
        {
            get { return datumKreiranja; }
            set { datumKreiranja = value; }
        }

        public DateTime? DatumDeaktiviranja
        {
            get { return datumDeaktiviranja; }
            set { datumDeaktiviranja = value; }
        }

        public int IdIndividualnogTreninga
        {
            get { return idIndividualnogTreninga; }
            set { idIndividualnogTreninga = value; }
        }


        internal TipIndividualniTreningDTO Tip
        {
            get { return tip; }
            set { tip = value; }
        }
        

        internal TrenerDTO Trener
        {
            get { return trener; }
            set { trener = value; }
        }
        

        internal ClanDTO Clan
        {
            get { return clan; }
            set { clan = value; }
        }



    }
}
