﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanacFitnesCentara.db.dto
{
    class TerminDTO
    {
        private int idTermina;
        private KoordinatorDTO koordinator;
        private String vrijeme;        
        private GrupaDTO grupa;
        private IndividualniTreningDTO individualniTrening;
        private DaniDTO danUSedmici;
        private SalaDTO sala;

        internal SalaDTO Sala
        {
            get { return sala; }
            set { sala = value; }
        }



        public DaniDTO DanUSedmici
        {
            get { return danUSedmici; }
            set { danUSedmici = value; }
        }

        public int IdTermina
        {
            get { return idTermina; }
            set { idTermina = value; }
        }
        

        internal KoordinatorDTO Koordinator
        {
            get { return koordinator; }
            set { koordinator = value; }
        }


        public String Vrijeme
        {
            get { return vrijeme; }
            set { vrijeme = value; }
        }
       

        internal GrupaDTO Grupa
        {
            get { return grupa; }
            set { grupa = value; }
        }
        

        internal IndividualniTreningDTO IndividualniTrening
        {
            get { return individualniTrening; }
            set { individualniTrening = value; }
        }



        public string KoordinatorDTO { get; set; }


        
    }
}
